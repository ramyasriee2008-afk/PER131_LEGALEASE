# LegalEase - AI-Powered Legal Document Generator

LegalEase is a full-featured, AI-powered legal document generation platform that turns contract parameters into professional, structured, and legally enforceable documents using **Google Gemini API**.

---

## 🏛️ Supported Legal Document Types
- **Employment Contract** (roles, salary, term, non-compete, benefits)
- **Non-Disclosure Agreement (NDA)** (mutual/unilateral, trade secrets, exclusions)
- **Lease Agreement** (premises, monthly rent, security deposit, maintenance)
- **Service Agreement** (scope of work, milestones, payment terms, warranties)
- **Freelance Contract** (deliverables, IP assignment, client approvals)
- **Employment Offer Letter** (salary, start date, equity, at-will status)
- **General Contract** & **General Agreement**
- **Partnership Agreement** & **Consulting Agreement**

---

## 🌟 Key Features
1. **Fact Integrity & Truthfulness**: Never fabricates facts or dollar values. If essential elements are omitted by the user, LegalEase flags them clearly with `[MISSING INFORMATION]` placeholders rather than inventing false details.
2. **Semicolon Term Parser**: Automatically converts user covenants separated by semicolons (e.g. `Payment within 30 days; Confidentiality must be maintained; 15 days notice`) into numbered covenants or terms tables.
3. **Multi-Format Export**:
   - **DOCX**: Formal Times New Roman, 1-inch margins, headers/footers, structured terms tables, and optional company logo embedding using `python-docx`.
   - **PDF**: Ready-to-execute PDF with pagination, margins, dividers, and logo via `FPDF` / `fpdf2`.
   - **TXT**: Plain-text export.
4. **Live Document Editor**: Modify any section of the generated contract in real-time. Edits are automatically preserved and reflected in all file downloads.
5. **Text Sanitizer (`sanitize_text`)**: Cleans problematic typographic characters (smart quotes, em-dashes, non-breaking spaces, ligatures) that break document compilation.
6. **Company Logo & Branding**: Upload company or firm logos to display in headers of DOCX, PDF, and live previews.

---

## 🚀 Running the Python (FastAPI + Streamlit) Application Locally

### Prerequisites
- Python 3.10+
- Valid `GEMINI_API_KEY`

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Environment
Set your Gemini API key in `.env`:
```bash
GEMINI_API_KEY="your_google_gemini_api_key"
FASTAPI_URL="http://localhost:8000"
```

### 3. Run the FastAPI Backend
```bash
cd python_app
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
```
API Documentation will be available at: `http://localhost:8000/docs`

### 4. Run the Streamlit Frontend
In a separate terminal:
```bash
cd python_app
streamlit run frontend/streamlit_app.py --server.port 8501
```
Open `http://localhost:8501` in your browser.

Or simply execute the all-in-one script:
```bash
chmod +x python_app/run.sh
./python_app/run.sh
```

---

## 🌐 Running the AI Studio Full-Stack Web App (Port 3000)
The repository also includes an Express + React full-stack application that mounts Vite and connects directly to Gemini via `@google/genai` on port 3000:
```bash
npm run dev
```

---

## 📡 FastAPI Endpoints
- `GET /health-check`: System health, Gemini configuration status, and supported document types.
- `POST /generate`: Generates document text from a Pydantic `DocumentRequest`.
- `POST /sanitize`: Cleans typographic symbols and formatting artifacts.
- `POST /export/docx`: Streams formatted `.docx` document.
- `POST /export/pdf`: Streams formatted `.pdf` document.

---

## ⚖️ Legal Disclaimer
*LegalEase generates AI-assisted legal documents for informational and drafting purposes only, and does not constitute formal legal advice. Please consult qualified legal counsel in your jurisdiction before executing binding contracts.*
