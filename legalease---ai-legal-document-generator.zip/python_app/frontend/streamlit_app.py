"""
LegalEase - Streamlit Frontend Application
AI-Powered Legal Document Generator
"""
import os
import sys
import io
import base64
import requests
from datetime import date
from PIL import Image
import streamlit as st
from dotenv import load_dotenv

load_dotenv()

# Add parent directory to path so utility imports work cleanly
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

try:
    from backend.utils.document_processor import (
        sanitize_text,
        parse_semicolon_terms,
        format_docx,
        format_pdf,
        format_html_preview
    )
    from backend.ai_core.gemini_generator import generate_legal_document
    LOCAL_BACKEND_AVAILABLE = True
except ImportError:
    LOCAL_BACKEND_AVAILABLE = False

# Backend URL configuration
FASTAPI_URL = os.getenv("FASTAPI_URL", "http://localhost:8000")

# Page Configuration
st.set_page_config(
    page_title="LegalEase | AI Legal Document Generator",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling (Dark Navy & Legal Professional Theme)
st.markdown("""
<style>
    /* Dark navy theme accents */
    .main {
        background-color: #0b1120;
    }
    .stApp {
        background: linear-gradient(180deg, #090e17 0%, #0f172a 100%);
        color: #f1f5f9;
        font-family: 'Inter', sans-serif;
    }
    .legal-title {
        font-family: 'Georgia', serif;
        font-size: 2.2rem;
        font-weight: 700;
        color: #f8fafc;
        letter-spacing: -0.02em;
        margin-bottom: 0.2rem;
    }
    .legal-subtitle {
        color: #94a3b8;
        font-size: 1.05rem;
        font-weight: 400;
        margin-bottom: 1.5rem;
    }
    .disclaimer-box {
        background-color: rgba(30, 41, 59, 0.7);
        border-left: 4px solid #f59e0b;
        padding: 0.85rem 1.2rem;
        border-radius: 0.375rem;
        color: #cbd5e1;
        font-size: 0.82rem;
        margin-top: 1.5rem;
        margin-bottom: 1.5rem;
    }
    .preview-container {
        background-color: #ffffff;
        color: #1e293b;
        padding: 2.5rem;
        border-radius: 0.5rem;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
        font-family: 'Times New Roman', 'Georgia', serif;
        line-height: 1.7;
        margin-top: 1rem;
        min-height: 400px;
    }
    .stButton>button {
        border-radius: 0.375rem;
        font-weight: 600;
        transition: all 0.2s ease;
    }
    .terms-card {
        background: #1e293b;
        border: 1px solid #334155;
        border-radius: 0.5rem;
        padding: 1rem;
        margin-top: 0.5rem;
        margin-bottom: 0.5rem;
    }
</style>
""", unsafe_allow_html=True)


# Initialize Session State
if "generated_text" not in st.session_state:
    st.session_state.generated_text = ""
if "edited_text" not in st.session_state:
    st.session_state.edited_text = ""
if "document_type" not in st.session_state:
    st.session_state.document_type = "Employment Contract"
if "structured_terms" not in st.session_state:
    st.session_state.structured_terms = []
if "logo_bytes" not in st.session_state:
    st.session_state.logo_bytes = None


# App Header
col_hdr_icon, col_hdr_text = st.columns([1, 11])
with col_hdr_icon:
    st.markdown("<div style='font-size: 3rem; text-align: center;'>⚖️</div>", unsafe_allow_html=True)
with col_hdr_text:
    st.markdown("<div class='legal-title'>LegalEase</div>", unsafe_allow_html=True)
    st.markdown("<div class='legal-subtitle'>AI-Powered Legal Document Generator</div>", unsafe_allow_html=True)

# Mandatory Legal Disclaimer
st.markdown("""
<div class='disclaimer-box'>
    ⚠️ <strong>LEGAL DISCLAIMER:</strong> LegalEase generates AI-assisted legal documents for informational and drafting purposes only, and does not constitute formal legal advice. Please consult qualified legal counsel in your jurisdiction before executing binding contracts.
</div>
""", unsafe_allow_html=True)


# SIDEBAR: Document Configuration
with st.sidebar:
    st.header("📄 Document Setup")
    
    # 1. Document Type Selection
    doc_type_options = [
        "Employment Contract",
        "Non-Disclosure Agreement (NDA)",
        "Lease Agreement",
        "Service Agreement",
        "Freelance Contract",
        "Employment Offer Letter",
        "General Contract",
        "General Agreement",
        "Partnership Agreement",
        "Consulting Agreement"
    ]
    doc_type = st.selectbox("1. Document Type", doc_type_options, index=0)

    # 2. Parties Involved
    st.subheader("👥 Parties Involved")
    parties_default = "ABC Tech Pvt. Ltd. (Employer), John Doe (Employee)" if doc_type == "Employment Contract" else ""
    parties = st.text_area(
        "Enter all parties with legal roles",
        value=parties_default,
        placeholder="e.g. ABC Tech Pvt. Ltd. (Employer), John Doe (Employee)\nor Acme Corp (Discloser) and Beta LLC (Recipient)",
        height=90
    )

    # 3. Terms & Conditions (Semicolon support)
    st.subheader("📋 Terms & Conditions")
    terms_default = (
        "Software Engineer role; annual salary of $60,000; 2-year term; "
        "confidentiality clause; payment within 30 days" if doc_type == "Employment Contract" else ""
    )
    terms = st.text_area(
        "Terms (separate multiple terms with semicolons ';')",
        value=terms_default,
        placeholder="e.g. Payment within 30 days; Confidentiality must be maintained; Either party may terminate with 15 days notice",
        height=120
    )

    # Preview structured terms parsed from semicolons
    parsed_covenants = parse_semicolon_terms(terms) if LOCAL_BACKEND_AVAILABLE else [t.strip() for t in terms.split(';') if t.strip()]
    if parsed_covenants:
        with st.expander(f"✨ Parsed Covenants ({len(parsed_covenants)})", expanded=False):
            for i, covenant in enumerate(parsed_covenants, 1):
                st.markdown(f"**{i}.** {covenant}")

    # 4. Effective Date & Duration
    st.subheader("📅 Dates & Term")
    col_d1, col_d2 = st.columns(2)
    with col_d1:
        effective_date = st.date_input("Effective Date", value=date(2025, 5, 1))
    with col_d2:
        term_duration = st.text_input("Term / Duration", value="2 years")

    jurisdiction = st.text_input("Governing Jurisdiction", value="State of California, United States")

    # 5. Additional Customization & Branding
    st.subheader("🎨 Customization & Branding")
    customizations = st.text_input(
        "Additional Instructions",
        value="Include company branding and professional formatting."
    )

    # Logo Upload
    uploaded_logo = st.file_uploader("Upload Company Logo (PNG/JPEG)", type=["png", "jpg", "jpeg"])
    if uploaded_logo:
        st.session_state.logo_bytes = uploaded_logo.read()
        try:
            pil_image = Image.open(io.BytesIO(st.session_state.logo_bytes))
            st.image(pil_image, caption="Company Logo Preview", width=140)
        except Exception:
            pass

    # Optional Clauses
    with st.expander("⚙️ Optional Clauses", expanded=False):
        inc_confidentiality = st.checkbox("Include Confidentiality Covenant", value=True)
        inc_severability = st.checkbox("Include Severability Clause", value=True)
        inc_dispute = st.checkbox("Include Arbitration / Dispute Resolution", value=True)

    # Generate Action Button
    generate_btn = st.button("🚀 Generate Document", type="primary", use_container_width=True)


# MAIN AREA: Generation & Preview / Editing
if generate_btn:
    if not parties.strip():
        st.error("Please enter the parties involved before generating.")
    else:
        with st.spinner("⚖️ Legal Counsel AI is drafting your structured legal document..."):
            date_str = effective_date.strftime("%B %d, %Y") if effective_date else ""
            
            # Attempt generation via FastAPI or local fallback
            generated = ""
            warnings = []
            
            try:
                # Try calling FastAPI backend
                resp = requests.post(
                    f"{FASTAPI_URL}/generate",
                    json={
                        "document_type": doc_type,
                        "parties": parties,
                        "terms": terms,
                        "effective_date": date_str,
                        "term_duration": term_duration,
                        "jurisdiction": jurisdiction,
                        "customizations": customizations,
                        "include_confidentiality": inc_confidentiality,
                        "include_severability": inc_severability,
                        "include_dispute_resolution": inc_dispute
                    },
                    timeout=30
                )
                if resp.status_code == 200:
                    data = resp.json()
                    generated = data.get("document_text", "")
                    warnings = data.get("missing_information_warnings", [])
                    st.session_state.structured_terms = data.get("structured_terms", [])
            except Exception:
                # Direct in-process execution fallback
                if LOCAL_BACKEND_AVAILABLE:
                    generated, warnings = generate_legal_document(
                        document_type=doc_type,
                        parties=parties,
                        terms=terms,
                        effective_date=date_str,
                        term_duration=term_duration,
                        jurisdiction=jurisdiction,
                        customizations=customizations,
                        include_confidentiality=inc_confidentiality,
                        include_severability=inc_severability,
                        include_dispute_resolution=inc_dispute
                    )
                    st.session_state.structured_terms = parsed_covenants

            if generated:
                st.session_state.generated_text = generated
                st.session_state.edited_text = generated
                st.session_state.document_type = doc_type
                st.success("Document successfully drafted!")
                if warnings:
                    for w in warnings:
                        st.warning(f"⚠️ Note: {w}")
            else:
                st.error("Failed to generate document. Please verify your GEMINI_API_KEY.")


# Display Document Area if content exists
current_text = st.session_state.edited_text or st.session_state.generated_text

if current_text:
    tab_preview, tab_edit, tab_terms = st.tabs(["📖 Document Preview", "✏️ Edit Document", "📊 Structured Covenants"])

    with tab_preview:
        # Action Bar with Downloads
        col_down1, col_down2, col_down3, col_down4 = st.columns([1.5, 1.5, 1.5, 2])
        
        # 1. TXT Export
        with col_down1:
            clean_txt = sanitize_text(st.session_state.edited_text) if LOCAL_BACKEND_AVAILABLE else st.session_state.edited_text
            st.download_button(
                label="📥 Download TXT",
                data=clean_txt,
                file_name=f"LegalEase_{st.session_state.document_type.replace(' ', '_')}.txt",
                mime="text/plain",
                use_container_width=True
            )

        # 2. DOCX Export
        with col_down2:
            if LOCAL_BACKEND_AVAILABLE:
                try:
                    docx_bytes = format_docx(
                        text=st.session_state.edited_text,
                        doc_type=st.session_state.document_type,
                        logo_bytes=st.session_state.logo_bytes,
                        title=st.session_state.document_type.upper(),
                        terms_list=st.session_state.structured_terms
                    )
                    st.download_button(
                        label="📄 Download DOCX",
                        data=docx_bytes,
                        file_name=f"LegalEase_{st.session_state.document_type.replace(' ', '_')}.docx",
                        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        use_container_width=True
                    )
                except Exception as e:
                    st.button("DOCX (Requires python-docx)", disabled=True)
            else:
                st.button("DOCX", disabled=True)

        # 3. PDF Export
        with col_down3:
            if LOCAL_BACKEND_AVAILABLE:
                try:
                    pdf_bytes = format_pdf(
                        text=st.session_state.edited_text,
                        doc_type=st.session_state.document_type,
                        logo_bytes=st.session_state.logo_bytes,
                        title=st.session_state.document_type.upper()
                    )
                    st.download_button(
                        label="📑 Download PDF",
                        data=bytes(pdf_bytes) if not isinstance(pdf_bytes, bytes) else pdf_bytes,
                        file_name=f"LegalEase_{st.session_state.document_type.replace(' ', '_')}.pdf",
                        mime="application/pdf",
                        use_container_width=True
                    )
                except Exception as e:
                    st.button("PDF (Requires fpdf2)", disabled=True)
            else:
                st.button("PDF", disabled=True)

        # 4. Text Sanitize helper
        with col_down4:
            if st.button("🧹 Sanitize Formatting & Typography"):
                if LOCAL_BACKEND_AVAILABLE:
                    st.session_state.edited_text = sanitize_text(st.session_state.edited_text)
                    st.toast("Document text successfully sanitized!")
                    st.rerun()

        # Document Paper Preview
        st.markdown("<div class='preview-container'>", unsafe_allow_html=True)
        if st.session_state.logo_bytes:
            try:
                b64_logo = base64.b64encode(st.session_state.logo_bytes).decode()
                st.markdown(f"<div style='text-align:center; margin-bottom:1.5rem;'><img src='data:image/png;base64,{b64_logo}' style='max-height:60px;'/></div>", unsafe_allow_html=True)
            except Exception:
                pass

        if LOCAL_BACKEND_AVAILABLE:
            html_view = format_html_preview(st.session_state.edited_text)
            st.markdown(html_view, unsafe_allow_html=True)
        else:
            st.markdown(st.session_state.edited_text)
        st.markdown("</div>", unsafe_allow_html=True)

    with tab_edit:
        st.subheader("✏️ Live Document Editor")
        st.caption("Modifications made below are preserved and directly applied to all PDF, DOCX, and TXT downloads.")
        
        updated_doc = st.text_area(
            "Document Text (Markdown format supported)",
            value=st.session_state.edited_text,
            height=600,
            key="edit_area"
        )
        if updated_doc != st.session_state.edited_text:
            st.session_state.edited_text = updated_doc

    with tab_terms:
        st.subheader("📊 Structured Covenants & Agreed Terms")
        if st.session_state.structured_terms:
            st.write("The following terms were extracted and translated into binding contractual clauses:")
            for i, term in enumerate(st.session_state.structured_terms, 1):
                st.markdown(f"""
                <div class='terms-card'>
                    <span style='color: #f59e0b; font-weight:700;'>Covenant {i}:</span>
                    <span style='color: #e2e8f0; margin-left: 0.5rem;'>{term}</span>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.info("No specific semicolon-separated terms entered.")

else:
    # Empty State Guide
    st.info("👈 Fill in the document details in the sidebar and click **'Generate Document'** to draft your legal agreement.")
    
    st.markdown("""
    ### 🛡️ Why LegalEase?
    - **Truthfulness Guaranteed**: Never invents non-provided facts; clearly tags missing essentials like salary or premises.
    - **Adaptive Legal Clauses**: Tailors non-disclosure, term lengths, and indemnities specifically for Employment, NDAs, Leases, and Freelance agreements.
    - **Multi-Format Export**: Generates authentic `.docx` (via python-docx with Times New Roman and formal margins), `.pdf` (via FPDF), and sanitized `.txt`.
    - **Company Branding**: Embed your corporate logo into document headers for execution-ready presentation.
    """)
