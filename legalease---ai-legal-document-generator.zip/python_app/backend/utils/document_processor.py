"""
LegalEase Document Processor Utilities
Handles text sanitization, structured terms extraction, and document exports (DOCX, PDF, HTML preview).
"""
import io
import re
import html
from typing import List, Optional, Tuple


def sanitize_text(text: str) -> str:
    """
    Cleans problematic characters and typographic symbols that cause document-formatting issues
    in PDF/DOCX engines and print renderers.
    """
    if not text:
        return ""

    replacements = {
        # Smart quotes & apostrophes
        '\u2018': "'",
        '\u2019': "'",
        '\u201A': "'",
        '\u201B': "'",
        '\u201C': '"',
        '\u201D': '"',
        '\u201E': '"',
        '\u201F': '"',
        '\u00AB': '"',  # Left-pointing double angle quotation mark
        '\u00BB': '"',  # Right-pointing double angle quotation mark
        # Dashes & hyphens
        '\u2013': '-',   # en-dash
        '\u2014': '--',  # em-dash
        '\u2015': '--',  # horizontal bar
        '\u2212': '-',   # minus sign
        # Spaces & invisible characters
        '\u00A0': ' ',   # non-breaking space
        '\u200B': '',    # zero-width space
        '\u200C': '',    # zero-width non-joiner
        '\u200D': '',    # zero-width joiner
        '\uFEFF': '',    # zero width no-break space (BOM)
        '\u202F': ' ',   # narrow non-breaking space
        '\u3000': ' ',   # ideographic space
        # Bullets & symbols
        '\u2022': '*',   # bullet
        '\u2023': '*',   # triangular bullet
        '\u25AA': '*',   # black small square
        '\u25CF': '*',   # black circle
        '\u2026': '...', # horizontal ellipsis
        # Ligatures
        '\uFB01': 'fi',
        '\uFB02': 'fl',
        '\uFB00': 'ff',
        '\uFB03': 'ffi',
        '\uFB04': 'ffl',
    }

    sanitized = text
    for orig, repl in replacements.items():
        sanitized = sanitized.replace(orig, repl)

    # Normalize weird control characters (preserve newlines, carriage returns, tabs)
    sanitized = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', sanitized)
    # Normalize multiple blank lines to double newlines
    sanitized = re.sub(r'\n{3,}', '\n\n', sanitized)
    return sanitized.strip()


def parse_semicolon_terms(terms_raw: str) -> List[str]:
    """
    Parses semicolon-separated or newline-separated terms into clean individual covenants.
    Example: 'Payment within 30 days; Confidentiality must be maintained; Either party may terminate with 15 days notice'
    """
    if not terms_raw:
        return []

    # If it contains semicolons, split by semicolons
    if ';' in terms_raw:
        raw_items = terms_raw.split(';')
    else:
        # Otherwise split by line breaks or bullet points
        raw_items = re.split(r'\n+|(?<=[.!?])\s+(?=[A-Z0-9])', terms_raw)

    cleaned = []
    for item in raw_items:
        t = item.strip().lstrip('-*•1234567890.) ')
        if t and len(t) > 2:
            cleaned.append(t)
    return cleaned


def format_html_preview(text: str) -> str:
    """
    Converts plain text or legal markdown into styled HTML for web/Streamlit preview.
    Handles headings (##, SECTION 1), bullet points, bold markers, and signature lines.
    """
    if not text:
        return "<p class='text-gray-500 italic'>No document content generated yet.</p>"

    lines = text.split('\n')
    html_out = []
    in_list = False

    for line in lines:
        stripped = line.strip()
        if not stripped:
            if in_list:
                html_out.append("</ul>")
                in_list = False
            html_out.append("<div class='h-3'></div>")
            continue

        # Major document title
        if stripped.startswith('# '):
            if in_list:
                html_out.append("</ul>")
                in_list = False
            title_text = html.escape(stripped[2:])
            html_out.append(f"<h1 style='text-align:center; font-family:serif; font-size:1.6rem; font-weight:700; text-transform:uppercase; letter-spacing:0.05em; margin-bottom:1rem; border-bottom:2px solid #334155; padding-bottom:0.5rem;'>{title_text}</h1>")
            continue

        # Section Heading
        if stripped.startswith('## ') or re.match(r'^(SECTION|ARTICLE|\d+\.)\s+[A-Z\s]{3,}', stripped):
            if in_list:
                html_out.append("</ul>")
                in_list = False
            heading_text = stripped[3:] if stripped.startswith('## ') else stripped
            heading_text = html.escape(heading_text)
            html_out.append(f"<h2 style='font-family:serif; font-size:1.2rem; font-weight:700; margin-top:1.5rem; margin-bottom:0.5rem; color:#1e293b;'>{heading_text}</h2>")
            continue

        # Subheading
        if stripped.startswith('### '):
            if in_list:
                html_out.append("</ul>")
                in_list = False
            sub_text = html.escape(stripped[4:])
            html_out.append(f"<h3 style='font-family:serif; font-size:1.05rem; font-weight:600; margin-top:1rem; margin-bottom:0.25rem; color:#334155;'>{sub_text}</h3>")
            continue

        # Bullet point or list item
        if stripped.startswith(('- ', '* ', '• ')) or re.match(r'^\([a-z0-9]\)\s+', stripped):
            if not in_list:
                html_out.append("<ul style='list-style-type:disc; margin-left:1.5rem; margin-bottom:0.75rem; line-height:1.6;'>")
                in_list = True
            bullet_body = re.sub(r'^([-*•]|\([a-z0-9]\))\s*', '', stripped)
            # convert bold markdown **text** to <strong>
            bullet_body = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', html.escape(bullet_body))
            html_out.append(f"<li style='margin-bottom:0.25rem;'>{bullet_body}</li>")
            continue

        if in_list:
            html_out.append("</ul>")
            in_list = False

        # Signature blocks or dividers
        if stripped.startswith('---') or stripped.startswith('___'):
            html_out.append("<hr style='border:0; border-top:1px solid #cbd5e1; margin:1.5rem 0;' />")
            continue

        # Paragraph text with bold support
        p_text = html.escape(stripped)
        p_text = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', p_text)
        html_out.append(f"<p style='font-family:serif; font-size:1rem; line-height:1.75; text-align:justify; margin-bottom:0.75rem; color:#1e293b;'>{p_text}</p>")

    if in_list:
        html_out.append("</ul>")

    return "\n".join(html_out)


def format_docx(
    text: str,
    doc_type: str,
    logo_bytes: Optional[bytes] = None,
    title: Optional[str] = None,
    parties: Optional[str] = None,
    terms_list: Optional[List[str]] = None
) -> bytes:
    """
    Generates a formal legal document in DOCX format using python-docx.
    Applies Times New Roman, formal margins, bold headings, and optional logo/table.
    """
    try:
        from docx import Document
        from docx.shared import Inches, Pt, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.enum.table import WD_TABLE_ALIGNMENT
        from docx.oxml import OxmlElement, parse_xml
        from docx.oxml.ns import nsdecls, qn
    except ImportError:
        raise RuntimeError("python-docx is not installed in the python environment.")

    doc = Document()

    # Set standard 1-inch margins
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)

        # Configure Header & Footer
        header = section.header
        hp = header.paragraphs[0]
        hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        hrun = hp.add_run(f"LEGAL DOCUMENT | {doc_type.upper()}")
        hrun.font.name = "Times New Roman"
        hrun.font.size = Pt(8.5)
        hrun.font.color.rgb = RGBColor(128, 128, 128)

        footer = section.footer
        fp = footer.paragraphs[0]
        fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        frun = fp.add_run("LegalEase Draft -- For Legal Drafting & Informational Purposes Only")
        frun.font.name = "Times New Roman"
        frun.font.size = Pt(8)
        frun.font.italic = True
        frun.font.color.rgb = RGBColor(140, 140, 140)

    # Optional Logo insertion
    if logo_bytes:
        try:
            image_stream = io.BytesIO(logo_bytes)
            logo_p = doc.add_paragraph()
            logo_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            logo_p.paragraph_format.space_after = Pt(12)
            run = logo_p.add_run()
            run.add_picture(image_stream, width=Inches(1.8))
        except Exception:
            pass

    # Title
    doc_title = title or doc_type.upper()
    title_p = doc.add_paragraph()
    title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_p.paragraph_format.space_before = Pt(6)
    title_p.paragraph_format.space_after = Pt(18)
    run_title = title_p.add_run(doc_title.upper())
    run_title.font.name = "Times New Roman"
    run_title.font.size = Pt(16)
    run_title.font.bold = True
    run_title.font.color.rgb = RGBColor(17, 24, 39)

    # Clean text content
    cleaned_text = sanitize_text(text)
    lines = cleaned_text.split('\n')

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        # Skip duplicate title line if it was in the text
        if stripped.startswith('# ') and stripped[2:].strip().upper() == doc_title.upper():
            continue

        # Major Headings
        if stripped.startswith('# ') or stripped.startswith('## '):
            h_text = stripped.lstrip('#').strip()
            h_p = doc.add_paragraph()
            h_p.paragraph_format.space_before = Pt(14)
            h_p.paragraph_format.space_after = Pt(4)
            h_p.paragraph_format.keep_with_next = True
            run = h_p.add_run(h_text)
            run.font.name = "Times New Roman"
            run.font.size = Pt(12.5)
            run.font.bold = True
            run.font.color.rgb = RGBColor(20, 30, 45)
            continue

        # Sub-headings / Numbered sections
        if stripped.startswith('### ') or re.match(r'^(SECTION|ARTICLE|\d+\.)\s+[A-Z\s]{3,}', stripped):
            sub_text = stripped[4:] if stripped.startswith('### ') else stripped
            h_p = doc.add_paragraph()
            h_p.paragraph_format.space_before = Pt(10)
            h_p.paragraph_format.space_after = Pt(3)
            h_p.paragraph_format.keep_with_next = True
            run = h_p.add_run(sub_text)
            run.font.name = "Times New Roman"
            run.font.size = Pt(11.5)
            run.font.bold = True
            run.font.color.rgb = RGBColor(30, 41, 59)
            continue

        # Bullet items
        if stripped.startswith(('- ', '* ', '• ')):
            bullet_body = stripped[2:].strip()
            bp = doc.add_paragraph(style='List Bullet')
            bp.paragraph_format.space_after = Pt(3)
            bp.paragraph_format.line_spacing = 1.15
            # Bold segments
            parts = re.split(r'(\*\*.*?\*\*)', bullet_body)
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    r = bp.add_run(part[2:-2])
                    r.bold = True
                else:
                    r = bp.add_run(part)
                r.font.name = "Times New Roman"
                r.font.size = Pt(11)
            continue

        # Horizontal rule / signature separator
        if stripped.startswith('---') or stripped.startswith('___'):
            sep_p = doc.add_paragraph()
            sep_p.paragraph_format.space_before = Pt(12)
            sep_p.paragraph_format.space_after = Pt(12)
            run = sep_p.add_run("________________________________________________")
            run.font.name = "Times New Roman"
            run.font.color.rgb = RGBColor(180, 180, 180)
            continue

        # Normal Paragraph
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        p.paragraph_format.line_spacing = 1.15
        p.paragraph_format.space_after = Pt(6)

        # Parse markdown bold
        parts = re.split(r'(\*\*.*?\*\*)', stripped)
        for part in parts:
            if part.startswith('**') and part.endswith('**'):
                r = p.add_run(part[2:-2])
                r.bold = True
            else:
                r = p.add_run(part)
            r.font.name = "Times New Roman"
            r.font.size = Pt(11)
            r.font.color.rgb = RGBColor(17, 24, 39)

    # If structured terms list is provided, append a structured Terms Table
    if terms_list and len(terms_list) > 0:
        table_title_p = doc.add_paragraph()
        table_title_p.paragraph_format.space_before = Pt(16)
        table_title_p.paragraph_format.space_after = Pt(6)
        run = table_title_p.add_run("SCHEDULE A -- SUMMARY OF KEY TERMS & CONDITIONS")
        run.font.name = "Times New Roman"
        run.font.size = Pt(11)
        run.font.bold = True

        table = doc.add_table(rows=1, cols=2)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.autofit = False

        # Header row
        hdr_cells = table.rows[0].cells
        hdr_cells[0].text = "Item #"
        hdr_cells[1].text = "Agreed Covenant / Term"
        for c in hdr_cells:
            for p in c.paragraphs:
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for r in p.runs:
                    r.font.name = "Times New Roman"
                    r.font.bold = True
                    r.font.size = Pt(10)
            # Add subtle gray background to header
            shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="E2E8F0"/>')
            c._tc.get_or_add_tcPr().append(shd)

        # Rows
        for i, term in enumerate(terms_list, 1):
            row_cells = table.add_row().cells
            row_cells[0].text = str(i)
            row_cells[1].text = term
            for c in row_cells:
                for p in c.paragraphs:
                    for r in p.runs:
                        r.font.name = "Times New Roman"
                        r.font.size = Pt(9.5)

    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


def format_pdf(
    text: str,
    doc_type: str,
    logo_bytes: Optional[bytes] = None,
    title: Optional[str] = None,
    parties: Optional[str] = None
) -> bytes:
    """
    Generates a professional legal PDF document using FPDF / fpdf2.
    Formats title, headings, clauses, margins, footer, and optional logo.
    """
    try:
        from fpdf import FPDF
    except ImportError:
        raise RuntimeError("fpdf2/fpdf is not installed in the python environment.")

    class LegalPDF(FPDF):
        def header(self):
            # Header on every page
            self.set_font('Times', 'I', 8)
            self.set_text_color(128, 128, 128)
            self.cell(0, 8, f"LEGAL DRAFT | {doc_type.upper()}", border=0, ln=1, align='R')
            self.set_draw_color(220, 220, 220)
            self.line(self.l_margin, self.get_y(), self.w - self.r_margin, self.get_y())
            self.ln(3)

        def footer(self):
            # Position at 1.5 cm from bottom
            self.set_y(-15)
            self.set_draw_color(220, 220, 220)
            self.line(self.l_margin, self.get_y(), self.w - self.r_margin, self.get_y())
            self.set_font('Times', 'I', 8)
            self.set_text_color(130, 130, 130)
            page_text = f"Page {self.page_no()}"
            disclaimer = "LegalEase AI Draft - Informational & Drafting Purposes Only"
            self.cell(100, 10, disclaimer, border=0, align='L')
            self.cell(0, 10, page_text, border=0, align='R')

    pdf = LegalPDF(orientation='P', unit='mm', format='A4')
    pdf.set_margins(left=20, top=20, right=20)
    pdf.set_auto_page_break(auto=True, margin=20)
    pdf.add_page()

    # Optional Logo
    if logo_bytes:
        try:
            import tempfile
            with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp_file:
                tmp_file.write(logo_bytes)
                tmp_path = tmp_file.name
            pdf.image(tmp_path, x=(pdf.w - 35) / 2, w=35)
            pdf.ln(5)
        except Exception:
            pass

    # Title
    doc_title = title or doc_type.upper()
    pdf.set_font('Times', 'B', 15)
    pdf.set_text_color(20, 30, 45)
    pdf.cell(0, 10, doc_title.upper(), border=0, ln=1, align='C')
    pdf.ln(4)

    # Sanitize content for PDF encoding (latin-1 compatible)
    cleaned = sanitize_text(text)
    # Replace non-ascii quotes or symbols that might fail in latin-1
    cleaned = cleaned.encode('latin-1', 'replace').decode('latin-1')

    lines = cleaned.split('\n')
    for line in lines:
        stripped = line.strip()
        if not stripped:
            pdf.ln(2)
            continue

        # Skip duplicate title
        if stripped.startswith('# ') and stripped[2:].strip().upper() == doc_title.upper():
            continue

        # Major Headings
        if stripped.startswith('# ') or stripped.startswith('## '):
            h_text = stripped.lstrip('#').strip()
            pdf.ln(3)
            pdf.set_font('Times', 'B', 11.5)
            pdf.set_text_color(25, 35, 50)
            pdf.cell(0, 7, h_text, border=0, ln=1, align='L')
            pdf.set_text_color(20, 20, 20)
            continue

        # Sub-sections
        if stripped.startswith('### ') or re.match(r'^(SECTION|ARTICLE|\d+\.)\s+[A-Z\s]{3,}', stripped):
            sub_text = stripped[4:] if stripped.startswith('### ') else stripped
            pdf.ln(2)
            pdf.set_font('Times', 'B', 10.5)
            pdf.cell(0, 6, sub_text, border=0, ln=1, align='L')
            continue

        # Bullet points
        if stripped.startswith(('- ', '* ', '• ')):
            bullet_body = stripped[2:].strip()
            clean_body = re.sub(r'\*\*(.*?)\*\*', r'\1', bullet_body)
            pdf.set_font('Times', '', 10)
            pdf.cell(6, 5, chr(149), border=0, align='R')
            pdf.multi_cell(0, 5, clean_body, align='L')
            pdf.ln(1)
            continue

        # Dividers / Signature separator
        if stripped.startswith('---') or stripped.startswith('___'):
            pdf.ln(3)
            pdf.cell(0, 5, "_" * 50, border=0, ln=1, align='L')
            pdf.ln(2)
            continue

        # Normal Paragraph
        clean_para = re.sub(r'\*\*(.*?)\*\*', r'\1', stripped)
        pdf.set_font('Times', '', 10)
        pdf.set_text_color(20, 20, 20)
        pdf.multi_cell(0, 5.2, clean_para, align='J')
        pdf.ln(2)

    return pdf.output()
