"""
LegalEase AI Core - Google Gemini Legal Document Generator
Generates professional, structured, legally rigorous agreements based on user parameters.
Detects missing required facts and preserves truthfulness without fabricating terms.
"""
import os
from typing import Dict, Any, List, Tuple
from dotenv import load_dotenv

load_dotenv()


def check_missing_information(
    document_type: str,
    parties: str,
    terms: str,
    effective_date: str
) -> List[str]:
    """
    Identifies if essential legal metadata is missing for the given document type.
    """
    warnings = []
    if not parties or len(parties.strip()) < 5 or "and" not in parties.lower() and "," not in parties:
        warnings.append("Specific identification of both legal parties (Discloser/Recipient, Employer/Employee, etc.) is incomplete.")

    if not effective_date or not effective_date.strip():
        warnings.append("Effective date was not specified. Draft uses bracketed placeholder [EFFECTIVE DATE].")

    dt_lower = document_type.lower()
    t_lower = terms.lower()

    if "employment" in dt_lower or "offer" in dt_lower:
        if "salary" not in t_lower and "compensation" not in t_lower and "pay" not in t_lower and "$" not in t_lower:
            warnings.append("Compensation or salary details were omitted; marked as [COMPENSATION TO BE SPECIFIED].")
        if "role" not in t_lower and "title" not in t_lower and "position" not in t_lower:
            warnings.append("Job title or scope of duties omitted; marked as [JOB TITLE / DUTIES].")

    elif "lease" in dt_lower:
        if "rent" not in t_lower and "$" not in t_lower:
            warnings.append("Rental amount and payment frequency omitted; marked as [MONTHLY RENT AMOUNT].")
        if "address" not in t_lower and "premises" not in t_lower and "property" not in t_lower:
            warnings.append("Specific property address omitted; marked as [PREMISES ADDRESS].")

    elif "nda" in dt_lower or "non-disclosure" in dt_lower:
        if "term" not in t_lower and "year" not in t_lower and "duration" not in t_lower:
            warnings.append("Confidentiality term length unspecified; marked as [CONFIDENTIALITY DURATION (e.g., 3 years)].")

    return warnings


def build_legal_system_prompt(document_type: str) -> str:
    return f"""You are LegalEase Senior Legal Counsel AI, an expert corporate and contract drafting attorney.
Your task is to draft a comprehensive, legally rigorous, enforceable, and professional {document_type}.

CORE DRAFTING RULES:
1. TRUTHFULNESS & FACT INTEGRITY:
   - Do NOT invent or fabricate facts, addresses, salary figures, or terms that the user did not supply.
   - If a standard element is missing from user input (such as compensation, governing city/state, or specific term length), explicitly mark it with uppercase bracketed placeholders, e.g. [INSERT SPECIFIC SALARY AMOUNT] or [INSERT PROPERTY ADDRESS], so the parties know it must be filled.
2. STRUCTURE & SECTIONS:
   - Begin with a centered, bold formal Title (e.g. # EMPLOYMENT AGREEMENT).
   - Recitals / Preamble: Identify the Parties and the Effective Date clearly.
   - Purpose & Background: WHEREAS clauses explaining the mutual intent.
   - Operative Covenants: Numbered Sections (e.g. SECTION 1. SCOPE OF SERVICES, SECTION 2. COMPENSATION & PAYMENT TERMS, SECTION 3. TERM & TERMINATION).
   - Dynamic Standard Boilerplate: Confidentiality, Intellectual Property, Governing Law, Severability, Entire Agreement, Force Majeure, Notices, and Dispute Resolution / Arbitration.
   - Formal Signature Execution Block: "IN WITNESS WHEREOF, the parties hereto have executed this Agreement as of the Effective Date written above." with signature lines, names, titles, and dates.
3. SEMICOLON TERMS INTEGRATION:
   - Any specific terms provided by the user (such as 'Payment within 30 days; Confidentiality must be maintained') must be translated into formal legal covenants within the appropriate numbered sections.
4. TONE & STYLE:
   - Formal legal phrasing ("covenants", "warrants", "agrees", "indemnifies").
   - Use Markdown formatting: '# ' for title, '## ' for sections, '### ' for subsections, and bolding for defined terms.
"""


def generate_legal_document(
    document_type: str,
    parties: str,
    terms: str,
    effective_date: str = "",
    term_duration: str = "",
    jurisdiction: str = "State of California, United States",
    customizations: str = "",
    include_confidentiality: bool = True,
    include_severability: bool = True,
    include_dispute_resolution: bool = True,
    api_key: str = None
) -> Tuple[str, List[str]]:
    """
    Calls Google Gemini API to generate the legal document text.
    Returns (document_text, warnings).
    """
    key = api_key or os.getenv("GEMINI_API_KEY")
    warnings = check_missing_information(document_type, parties, terms, effective_date)

    prompt = f"""Draft a complete, formal, and enforceable {document_type} based strictly on the following parameters:

DOCUMENT TYPE: {document_type}
PARTIES: {parties}
EFFECTIVE DATE: {effective_date if effective_date else '[EFFECTIVE DATE TO BE INSERTED]'}
TERM / DURATION: {term_duration if term_duration else '[TERM AS MUTUALLY AGREED]'}
GOVERNING JURISDICTION: {jurisdiction}

USER TERMS & COVENANTS:
{terms}

ADDITIONAL CUSTOMIZATION / BRANDING INSTRUCTIONS:
{customizations if customizations else 'Standard formal corporate presentation and strict legal formatting.'}

OPTIONAL CLAUSES REQUESTED:
- Confidentiality / Non-Disclosure: {'Yes, include comprehensive clause' if include_confidentiality else 'Omit'}
- Severability: {'Yes, standard severability clause' if include_severability else 'Omit'}
- Dispute Resolution / Arbitration: {'Yes, binding arbitration & mediation' if include_dispute_resolution else 'Omit'}

Provide the complete text of the legal agreement formatted in clear Markdown with numbered sections, recitals, and signature block. Do not provide commentary or chit-chat; output only the legal document text.
"""

    # If GEMINI_API_KEY is available, use Google GenAI SDK
    if key:
        try:
            # Modern Google GenAI SDK (from google-genai package)
            from google import genai
            from google.genai import types

            client = genai.Client(
                api_key=key,
                http_options={'headers': {'User-Agent': 'aistudio-build'}}
            )
            response = client.models.generateContent(
                model="gemini-3.8-flash",
                contents=prompt,
                config=types.GenerateContentConfig(
                    system_instruction=build_legal_system_prompt(document_type),
                    temperature=0.2, # Low temperature for accurate legal drafting
                )
            )
            if response and response.text:
                return response.text.strip(), warnings
        except Exception as e:
            # Fallback attempt with legacy SDK or alternative if installed
            try:
                import google.generativeai as legacy_genai
                legacy_genai.configure(api_key=key)
                model = legacy_genai.GenerativeModel("gemini-1.5-flash")
                res = model.generate_content(prompt)
                if res and res.text:
                    return res.text.strip(), warnings
            except Exception as legacy_err:
                warnings.append(f"Gemini API execution note: {str(e)}")

    # Fallback high-fidelity template generator if API key is not yet set or during offline testing
    fallback_doc = generate_structured_template(
        document_type=document_type,
        parties=parties,
        terms=terms,
        effective_date=effective_date,
        term_duration=term_duration,
        jurisdiction=jurisdiction,
        customizations=customizations,
        include_confidentiality=include_confidentiality,
        include_severability=include_severability,
        include_dispute_resolution=include_dispute_resolution
    )
    return fallback_doc, warnings


def generate_structured_template(
    document_type: str,
    parties: str,
    terms: str,
    effective_date: str = "",
    term_duration: str = "",
    jurisdiction: str = "State of California, United States",
    customizations: str = "",
    include_confidentiality: bool = True,
    include_severability: bool = True,
    include_dispute_resolution: bool = True
) -> str:
    """
    Generates a rigorous fallback legal document structure if API call is in demo mode or offline.
    """
    date_str = effective_date if effective_date else "[EFFECTIVE DATE]"
    duration_str = term_duration if term_duration else "two (2) years from the Effective Date"

    # Break terms by semicolon
    items = [t.strip() for t in terms.split(';') if t.strip()]
    if not items:
        items = [terms] if terms else ["Terms as mutually agreed between parties in writing."]

    formatted_terms = ""
    for idx, item in enumerate(items, 1):
        formatted_terms += f"**Section 3.{idx}. Agreed Covenant:** {item}\n\n"

    template = f"""# {document_type.upper()}

This **{document_type}** (the "Agreement") is entered into and made effective as of **{date_str}** (the "Effective Date"), by and between the parties identified below:

**PARTIES TO THIS AGREEMENT:**
{parties}

(Collectively referred to herein as the "Parties" and each individually as a "Party").

---

### RECITALS

**WHEREAS**, the Parties desire to establish a formal legal relationship pursuant to the covenants and agreements set forth herein; and

**WHEREAS**, each Party has the full corporate and individual legal capacity and authority to enter into and perform the obligations set forth in this Agreement;

**NOW, THEREFORE**, in consideration of the mutual covenants, promises, and valuable considerations herein recited, the receipt and legal sufficiency of which are hereby acknowledged, the Parties agree as follows:

---

## SECTION 1. SCOPE AND ENGAGEMENT
1.1 **Purpose and Engagement.** The Parties hereby agree to perform their respective obligations, roles, and responsibilities as contemplated under this {document_type}.
1.2 **Standard of Performance.** Each Party covenants to act in good faith, in accordance with applicable industry standards, and in strict compliance with all relevant laws and regulations.

## SECTION 2. TERM AND DURATION
2.1 **Term.** This Agreement shall commence on the Effective Date and shall continue in full force and effect for **{duration_str}**, unless terminated earlier in accordance with the provisions herein.
2.2 **Termination for Cause.** Either Party may terminate this Agreement immediately upon written notice if the other Party materially breaches any term and fails to cure such breach within fifteen (15) days of receipt of written notice.

## SECTION 3. SPECIFIC TERMS AND COVENANTS
The Parties have agreed to the following specific covenants, terms, and specifications:

{formatted_terms}
"""

    if include_confidentiality:
        template += """## SECTION 4. CONFIDENTIALITY AND NON-DISCLOSURE
4.1 **Confidential Information.** Each Party agrees that all confidential or proprietary technical, financial, and operational information disclosed during the term of this Agreement shall remain strictly confidential.
4.2 **Standard of Care.** The receiving Party shall protect such Confidential Information with the same degree of care it exercises for its own confidential data, but in no event less than a reasonable degree of care.
4.3 **Exclusions.** Confidential Information does not include information that is publicly known through no breach, was already rightfully possessed, or is required to be disclosed pursuant to a valid judicial order.

"""

    template += f"""## SECTION 5. GOVERNING LAW AND JURISDICTION
5.1 **Governing Law.** This Agreement shall be construed, interpreted, and governed in accordance with the substantive laws of **{jurisdiction}**, without giving effect to conflicts of law principles.
"""

    if include_dispute_resolution:
        template += """5.2 **Dispute Resolution.** Any dispute, claim, or controversy arising out of or relating to this Agreement shall first be negotiated in good faith by executive representatives. If unresolved within thirty (30) days, such dispute shall be submitted to binding arbitration under the rules of the American Arbitration Association.

"""

    if include_severability:
        template += """## SECTION 6. SEVERABILITY AND ENTIRE AGREEMENT
6.1 **Severability.** If any provision of this Agreement is held to be invalid or unenforceable, such provision shall be severed and the remaining provisions shall continue in full legal effect.
6.2 **Entire Agreement.** This document constitutes the entire agreement between the Parties with respect to the subject matter hereof and supersedes all prior representations, negotiations, or understandings.

"""

    template += """---

### EXECUTION AND SIGNATURES

**IN WITNESS WHEREOF**, the Parties hereto have duly executed this Agreement by their authorized representatives as of the Effective Date written above.


_____________________________________________
**FOR PARTY 1 / EMPLOYER / DISCLOSER**
Authorized Signature: _______________________
Printed Name: _______________________________
Title: ______________________________________
Date: _______________________________________


_____________________________________________
**FOR PARTY 2 / EMPLOYEE / RECIPIENT**
Authorized Signature: _______________________
Printed Name: _______________________________
Title: ______________________________________
Date: _______________________________________
"""

    return template
