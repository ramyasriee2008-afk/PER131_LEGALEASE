"""
LegalEase FastAPI Application Entrypoint
Run locally via:
  uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
"""
import os
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

# Load environment variables (.env)
load_dotenv()

from backend.routes import router

app = FastAPI(
    title="LegalEase - AI Legal Document Generator API",
    description="FastAPI Backend providing Gemini-powered legal document generation, DOCX/PDF export, and text sanitization.",
    version="1.0.0"
)

# Enable CORS for local Streamlit, React, or external consumers
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount routes
app.include_router(router, prefix="/api")
app.include_router(router)  # also mount at root for /health-check and /generate directly


if __name__ == "__main__":
    port = int(os.getenv("PORT", 8000))
    print(f"Starting LegalEase FastAPI on port {port}...")
    uvicorn.run("backend.main:app", host="0.0.0.0", port=port, reload=True)
