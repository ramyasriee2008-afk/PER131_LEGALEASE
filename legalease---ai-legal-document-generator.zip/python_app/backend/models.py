"""
LegalEase Pydantic Models for API Requests and Responses
"""
from typing import List, Optional
from pydantic import BaseModel, Field


class DocumentRequest(BaseModel):
    document_type: str = Field(
        ...,
        description="The type of legal document (e.g., Employment Contract, NDA, Lease Agreement)",
        example="Employment Contract"
    )
    parties: str = Field(
        ...,
        description="Parties involved in the contract with their roles",
        example="ABC Tech Pvt. Ltd. (Employer), John Doe (Employee)"
    )
    terms: str = Field(
        ...,
        description="Terms and conditions, optionally semicolon-separated",
        example="Software Engineer role; annual salary of $60,000; 2-year term; confidentiality clause; payment within 30 days"
    )
    effective_date: Optional[str] = Field(
        default=None,
        description="Effective date of the document (YYYY-MM-DD or formal date)",
        example="2025-05-01"
    )
    term_duration: Optional[str] = Field(
        default=None,
        description="Duration of the agreement (e.g., 2 years, At-will, 12 months)",
        example="2 years"
    )
    jurisdiction: Optional[str] = Field(
        default="State of California, United States",
        description="Governing jurisdiction for legal enforcement",
        example="State of California, United States"
    )
    customizations: Optional[str] = Field(
        default="",
        description="Additional customizations or specific branding instructions",
        example="Include company branding and professional formatting."
    )
    include_confidentiality: Optional[bool] = Field(
        default=True,
        description="Whether to include explicit non-disclosure covenants"
    )
    include_severability: Optional[bool] = Field(
        default=True,
        description="Whether to include standard severability clause"
    )
    include_dispute_resolution: Optional[bool] = Field(
        default=True,
        description="Whether to include arbitration or dispute resolution clause"
    )


class DocumentResponse(BaseModel):
    success: bool
    title: str
    document_type: str
    parties: str
    effective_date: str
    document_text: str
    structured_terms: List[str]
    missing_information_warnings: List[str] = []
    error: Optional[str] = None


class SanitizeRequest(BaseModel):
    text: str


class SanitizeResponse(BaseModel):
    sanitized_text: str
    changes_made: int


class HealthResponse(BaseModel):
    status: str
    service: str
    version: str
    gemini_configured: bool
    supported_document_types: List[str]
