"""
LegalEase FastAPI Route Endpoints
Handles document generation, health checking, text sanitization, and document export.
"""
import base64
import io
from fastapi import APIRouter, HTTPException, Response
from fastapi.responses import StreamingResponse

from backend.models import (
    DocumentRequest,
    DocumentResponse,
    SanitizeRequest,
    SanitizeResponse,
    HealthResponse
)
from backend.ai_core.gemini_generator import generate_legal_document
from backend.utils.document_processor import (
    sanitize_text,
    parse_semicolon_terms,
    format_docx,
    format_pdf
)

router = APIRouter()

SUPPORTED_TYPES = [
    "Employment Contract",
    "Non-Disclosure Agreement (NDA)",
    "Lease Agreement",
    "Service Agreement",
    "Freelance Contract",
    "Employment Offer Letter",
    "General Contract",
    "General Agreement",
    "Partnership Agreement",
    "Consulting Agreement"
]


@router.get("/health-check", response_model=HealthResponse)
@router.get("/", response_model=HealthResponse)
def health_check():
    """
    Health check endpoint returning system status and supported document types.
    """
    import os
    has_gemini = bool(os.getenv("GEMINI_API_KEY"))
    return HealthResponse(
        status="operational",
        service="LegalEase AI Backend",
        version="1.0.0",
        gemini_configured=has_gemini,
        supported_document_types=SUPPORTED_TYPES
    )


@router.post("/generate", response_model=DocumentResponse)
def generate_document(req: DocumentRequest):
    """
    Main document generation endpoint.
    Receives document_type, parties, terms, dates, customizations, and returns
    structured legal document text along with missing-information warnings.
    """
    if not req.document_type or not req.parties:
        raise HTTPException(
            status_code=400,
            detail="Both 'document_type' and 'parties' are mandatory fields."
        )

    structured_terms = parse_semicolon_terms(req.terms)

    try:
        doc_text, warnings = generate_legal_document(
            document_type=req.document_type,
            parties=req.parties,
            terms=req.terms,
            effective_date=req.effective_date or "",
            term_duration=req.term_duration or "",
            jurisdiction=req.jurisdiction or "State of California, United States",
            customizations=req.customizations or "",
            include_confidentiality=req.include_confidentiality,
            include_severability=req.include_severability,
            include_dispute_resolution=req.include_dispute_resolution
        )

        title = f"{req.document_type.upper()}"
        return DocumentResponse(
            success=True,
            title=title,
            document_type=req.document_type,
            parties=req.parties,
            effective_date=req.effective_date or "To be determined",
            document_text=doc_text,
            structured_terms=structured_terms,
            missing_information_warnings=warnings
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generation failed: {str(e)}")


@router.post("/sanitize", response_model=SanitizeResponse)
def sanitize_endpoint(req: SanitizeRequest):
    """
    Cleans typographic artifacts and problematic characters from legal text.
    """
    original = req.text
    sanitized = sanitize_text(original)
    diff_count = sum(1 for a, b in zip(original, sanitized) if a != b) + abs(len(original) - len(sanitized))
    return SanitizeResponse(
        sanitized_text=sanitized,
        changes_made=diff_count
    )


@router.post("/export/docx")
def export_docx_endpoint(
    text: str,
    doc_type: str = "Legal Document",
    title: str = "LEGAL AGREEMENT",
    logo_base64: str = None
):
    """
    Generates and downloads a .docx file for the document.
    """
    logo_bytes = base64.b64decode(logo_base64) if logo_base64 else None
    docx_bytes = format_docx(
        text=text,
        doc_type=doc_type,
        logo_bytes=logo_bytes,
        title=title
    )
    return StreamingResponse(
        io.BytesIO(docx_bytes),
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f"attachment; filename=LegalEase_{doc_type.replace(' ', '_')}.docx"}
    )


@router.post("/export/pdf")
def export_pdf_endpoint(
    text: str,
    doc_type: str = "Legal Document",
    title: str = "LEGAL AGREEMENT",
    logo_base64: str = None
):
    """
    Generates and downloads a .pdf file for the document.
    """
    logo_bytes = base64.b64decode(logo_base64) if logo_base64 else None
    pdf_bytes = format_pdf(
        text=text,
        doc_type=doc_type,
        logo_bytes=logo_bytes,
        title=title
    )
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=LegalEase_{doc_type.replace(' ', '_')}.pdf"}
    )
