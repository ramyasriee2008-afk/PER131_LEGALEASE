#!/bin/bash
# LegalEase Local Execution Script
# Sets up virtual environment, installs requirements, and launches FastAPI and Streamlit

set -e

echo "=========================================="
echo "   LegalEase - AI Legal Document Generator"
echo "=========================================="

if [ -z "$GEMINI_API_KEY" ]; then
    echo "⚠️  WARNING: GEMINI_API_KEY environment variable is not set."
    echo "    Export it using: export GEMINI_API_KEY='your_api_key'"
    echo "    Continuing with built-in high-fidelity legal fallback templates."
fi

# Create virtualenv if not present
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

echo "Activating virtual environment..."
source venv/bin/activate

echo "Installing requirements..."
pip install -r requirements.txt

echo "Starting FastAPI Backend on port 8000 in background..."
uvicorn backend.main:app --host 0.0.0.0 --port 8000 &
BACKEND_PID=$!

echo "Waiting for FastAPI backend to initialize..."
sleep 2

echo "Starting Streamlit Frontend on port 8501..."
streamlit run frontend/streamlit_app.py --server.port 8501 --server.address 0.0.0.0

# When Streamlit exits, kill backend
kill $BACKEND_PID
