import React, { useState, useEffect, useRef } from 'react';
import {
  Scale,
  FileText,
  Download,
  Copy,
  Check,
  Sparkles,
  AlertTriangle,
  Upload,
  Eye,
  Edit3,
  ListFilter,
  Layers,
  Building2,
  Calendar,
  Shield,
  Gavel,
  RefreshCw,
  Code2,
  Trash2,
  ExternalLink,
  ChevronDown,
  Info
} from 'lucide-react';

import { LEGAL_PRESETS, LegalPreset } from './data/templates';
import {
  sanitizeLegalText,
  downloadTxt,
  downloadDocx,
  downloadPdf,
} from './utils/documentExport';
import { PythonArchitectureViewer } from './components/PythonArchitectureViewer';

export default function App() {
  // Document Configuration State
  const [documentType, setDocumentType] = useState<string>('Employment Contract');
  const [parties, setParties] = useState<string>(
    'ABC Tech Pvt. Ltd. (Employer), John Doe (Employee)'
  );
  const [terms, setTerms] = useState<string>(
    'Software Engineer role; annual salary of $60,000; 2-year term; confidentiality clause; payment terms bi-weekly; 15 days written notice for termination'
  );
  const [effectiveDate, setEffectiveDate] = useState<string>('2025-05-01');
  const [termDuration, setTermDuration] = useState<string>('2 years');
  const [jurisdiction, setJurisdiction] = useState<string>('State of California, United States');
  const [customizations, setCustomizations] = useState<string>(
    'Include company branding and professional formatting.'
  );

  // Optional Clauses
  const [includeConfidentiality, setIncludeConfidentiality] = useState<boolean>(true);
  const [includeSeverability, setIncludeSeverability] = useState<boolean>(true);
  const [includeDisputeResolution, setIncludeDisputeResolution] = useState<boolean>(true);

  // Logo & Branding State
  const [logoBase64, setLogoBase64] = useState<string>('');
  const [companyName, setCompanyName] = useState<string>('ABC Tech Pvt. Ltd.');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Document Result State
  const [generatedDoc, setGeneratedDoc] = useState<string>('');
  const [editedDoc, setEditedDoc] = useState<string>('');
  const [missingWarnings, setMissingWarnings] = useState<string[]>([]);
  const [structuredTerms, setStructuredTerms] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'preview' | 'edit' | 'terms'>('preview');

  // UI Processing State
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generationStep, setGenerationStep] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [sanitizedNotice, setSanitizedNotice] = useState<boolean>(false);
  const [showArchModal, setShowArchModal] = useState<boolean>(false);
  const [paperTheme, setPaperTheme] = useState<'formal' | 'dark'>('formal');

  // Document types list
  const docTypes = [
    'Employment Contract',
    'Non-Disclosure Agreement (NDA)',
    'Lease Agreement',
    'Service Agreement',
    'Freelance Contract',
    'Employment Offer Letter',
    'General Contract',
    'General Agreement',
    'Partnership Agreement',
    'Consulting Agreement',
  ];

  // Parse terms separated by semicolons
  const parseTerms = (text: string): string[] => {
    if (!text) return [];
    if (text.includes(';')) {
      return text
        .split(';')
        .map((t) => t.trim().replace(/^[-*•\d.)\s]+/, ''))
        .filter((t) => t.length > 2);
    }
    return text
      .split(/\n+/)
      .map((t) => t.trim().replace(/^[-*•\d.)\s]+/, ''))
      .filter((t) => t.length > 2);
  };

  const parsedCovenants = parseTerms(terms);

  // Load a preset template
  const handleApplyPreset = (preset: LegalPreset) => {
    setDocumentType(preset.documentType);
    setParties(preset.defaultParties);
    setTerms(preset.defaultTerms);
    setTermDuration(preset.defaultDuration);
    setJurisdiction(preset.defaultJurisdiction);
    setCustomizations(preset.customizationNotes);
  };

  // Handle Logo Upload
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setLogoBase64(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Primary Document Generation Handler
  const handleGenerateDocument = async () => {
    if (!parties.trim()) {
      alert('Please enter the parties involved in the contract.');
      return;
    }

    setIsGenerating(true);
    setGenerationStep('Analyzing document scope and parties...');

    try {
      setTimeout(() => setGenerationStep('Synthesizing structured covenants & clauses...'), 600);
      setTimeout(() => setGenerationStep('Verifying fact integrity & missing facts...'), 1200);

      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          document_type: documentType,
          parties,
          terms,
          effective_date: effectiveDate,
          term_duration: termDuration,
          jurisdiction,
          customizations,
          include_confidentiality: includeConfidentiality,
          include_severability: includeSeverability,
          include_dispute_resolution: includeDisputeResolution,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      setGeneratedDoc(data.document_text);
      setEditedDoc(data.document_text);
      setMissingWarnings(data.missing_information_warnings || []);
      setStructuredTerms(data.structured_terms || parsedCovenants);
      setActiveTab('preview');
    } catch (err: any) {
      console.error('Generation error:', err);
      // Local client fallback generation if network error
      const covenants = parseTerms(terms);
      let fallbackDoc = `# ${documentType.toUpperCase()}\n\n`;
      fallbackDoc += `This **${documentType}** (the "Agreement") is made effective as of **${effectiveDate || '[EFFECTIVE DATE]'}**, by and between:\n\n`;
      fallbackDoc += `**PARTIES:**\n${parties}\n\n---\n\n`;
      fallbackDoc += `### RECITALS\n**WHEREAS**, the Parties wish to formalize their binding legal agreement; and\n**WHEREAS**, each Party is duly authorized to execute this Agreement;\n\n**NOW, THEREFORE**, the Parties covenant and agree as follows:\n\n`;
      fallbackDoc += `## SECTION 1. SCOPE OF AGREEMENT\n1.1 The Parties shall perform their respective covenants in accordance with this ${documentType}.\n\n`;
      fallbackDoc += `## SECTION 2. SPECIFIC COVENANTS & TERMS\n`;
      covenants.forEach((c, idx) => {
        fallbackDoc += `**2.${idx + 1}. Agreed Covenant:** ${c}\n\n`;
      });
      if (includeConfidentiality) {
        fallbackDoc += `## SECTION 3. CONFIDENTIALITY\nEach party shall protect confidential information with strict professional care.\n\n`;
      }
      fallbackDoc += `## SECTION 4. GOVERNING LAW\nGoverned under the laws of ${jurisdiction}.\n\n`;
      fallbackDoc += `---\n\n### EXECUTION AND SIGNATURES\n\n**IN WITNESS WHEREOF**, the parties have executed this Agreement as of the date first above written.\n\n_______________________________\nSignature for Party 1\nDate: _________________________\n\n_______________________________\nSignature for Party 2\nDate: _________________________\n`;
      
      setGeneratedDoc(fallbackDoc);
      setEditedDoc(fallbackDoc);
      setStructuredTerms(covenants);
    } finally {
      setIsGenerating(false);
      setGenerationStep('');
    }
  };

  // Quick Append Term
  const appendQuickClause = (clause: string) => {
    if (terms.trim().length > 0 && !terms.trim().endsWith(';')) {
      setTerms(terms.trim() + '; ' + clause);
    } else if (terms.trim().endsWith(';')) {
      setTerms(terms.trim() + ' ' + clause);
    } else {
      setTerms(clause);
    }
  };

  // Copy to clipboard
  const handleCopyDocument = () => {
    const textToCopy = editedDoc || generatedDoc;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Sanitize text button
  const handleSanitizeText = () => {
    const current = editedDoc || generatedDoc;
    const sanitized = sanitizeLegalText(current);
    setEditedDoc(sanitized);
    setSanitizedNotice(true);
    setTimeout(() => setSanitizedNotice(false), 2500);
  };

  // Generate on initial mount if empty so user has immediate preview
  useEffect(() => {
    if (!generatedDoc) {
      handleGenerateDocument();
    }
  }, []);

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Navigation Bar */}
      <header className="border-b border-slate-800/80 bg-slate-950/90 backdrop-blur sticky top-0 z-40 px-4 lg:px-8 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 p-0.5 shadow-lg shadow-amber-950/40 flex items-center justify-center text-slate-950">
            <Scale className="w-5 h-5 text-slate-950 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-cinzel text-xl font-bold tracking-tight text-white">
                LegalEase
              </span>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-amber-400 bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded">
                AI Counsel
              </span>
            </div>
            <p className="text-xs text-slate-400 font-normal">
              AI-Powered Legal Document Generator · Google Gemini 3.8 Flash
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Preset Selector Dropdown */}
          <div className="relative hidden md:block">
            <select
              onChange={(e) => {
                const found = LEGAL_PRESETS.find((p) => p.id === e.target.value);
                if (found) handleApplyPreset(found);
              }}
              defaultValue=""
              className="bg-slate-900 border border-slate-700 text-xs text-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:border-amber-500 cursor-pointer pr-8 appearance-none"
            >
              <option value="" disabled>
                ⚡ Load Sample Preset...
              </option>
              {LEGAL_PRESETS.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2.5 pointer-events-none" />
          </div>

          {/* Python Architecture & Streamlit Viewer */}
          <button
            onClick={() => setShowArchModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-xs text-amber-300 font-medium transition"
            title="Inspect Python FastAPI & Streamlit Code"
          >
            <Code2 className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Python Architecture</span>
          </button>
        </div>
      </header>

      {/* Mandatory Legal Disclaimer Bar */}
      <div className="bg-amber-950/20 border-b border-amber-900/30 px-4 lg:px-8 py-2 text-xs text-amber-200/90 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            <strong>Legal Disclaimer:</strong> LegalEase generates AI-assisted legal documents for informational and drafting purposes only, and does not constitute formal legal advice.
          </span>
        </div>
        <span className="text-[11px] text-amber-400/70 hidden sm:inline">
          Consult licensed legal counsel before execution
        </span>
      </div>

      {/* Main Grid: Sidebar Configuration & Main Document Area */}
      <div className="flex-1 flex flex-col lg:flex-row max-w-[1600px] w-full mx-auto">
        {/* LEFT COLUMN: Sidebar Configuration Panel */}
        <aside className="w-full lg:w-[460px] xl:w-[490px] border-r border-slate-800/80 bg-slate-950/60 p-5 lg:p-6 overflow-y-auto space-y-6 shrink-0">
          <div>
            <h2 className="text-sm font-semibold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              Document Configuration
            </h2>
            <p className="text-xs text-slate-500">
              Configure legal parameters, covenants, parties, and corporate branding
            </p>
          </div>

          {/* 1. Document Type */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
              <span>1. Document Type</span>
              <span className="text-[11px] text-amber-400/80">Adaptive clauses</span>
            </label>
            <select
              value={documentType}
              onChange={(e) => setDocumentType(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-amber-500"
            >
              {docTypes.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          {/* 2. Parties Involved */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
              <span>2. Parties Involved</span>
              <span className="text-[11px] text-slate-400">Legal names & roles</span>
            </label>
            <textarea
              rows={2}
              value={parties}
              onChange={(e) => setParties(e.target.value)}
              placeholder="e.g. ABC Tech Pvt. Ltd. (Employer), John Doe (Employee)"
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500 resize-none font-mono"
            />
          </div>

          {/* 3. Terms & Conditions with Semicolon Support */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300">
                3. Terms & Conditions
              </label>
              <span className="text-[11px] text-amber-400">
                Semicolon-separated (;)
              </span>
            </div>
            <textarea
              rows={4}
              value={terms}
              onChange={(e) => setTerms(e.target.value)}
              placeholder="e.g. Payment within 30 days; Confidentiality must be maintained; Either party may terminate with 15 days notice"
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500 resize-none font-mono leading-relaxed"
            />

            {/* Quick Semicolon Clause Injectors */}
            <div className="space-y-1 pt-1">
              <span className="text-[11px] text-slate-400">Quick Clause Additions:</span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Payment within 30 days',
                  'Confidentiality clause',
                  '15 days termination notice',
                  'IP ownership transfer',
                  'At-will employment',
                  'Non-compete 12 months',
                ].map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => appendQuickClause(item)}
                    className="text-[11px] bg-slate-800/90 hover:bg-slate-700 text-slate-300 px-2 py-0.5 rounded border border-slate-700/60 transition"
                  >
                    + {item}
                  </button>
                ))}
              </div>
            </div>

            {/* Semicolon Parsing Preview Box */}
            {parsedCovenants.length > 0 && (
              <div className="bg-slate-900/70 border border-slate-800 rounded-lg p-2.5 mt-2 space-y-1.5">
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium">
                  <span className="flex items-center gap-1.5">
                    <ListFilter className="w-3 h-3 text-amber-400" />
                    Structured Covenants Detected ({parsedCovenants.length})
                  </span>
                  <span className="text-emerald-400">Mapped to Schedule A</span>
                </div>
                <div className="space-y-1 max-h-28 overflow-y-auto pr-1">
                  {parsedCovenants.map((cov, idx) => (
                    <div
                      key={idx}
                      className="text-[11px] text-slate-300 flex items-start gap-1.5 font-mono"
                    >
                      <span className="text-amber-500 font-semibold">{idx + 1}.</span>
                      <span className="line-clamp-1">{cov}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 4. Effective Date & Duration */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1">
                <Calendar className="w-3 h-3 text-amber-400" />
                4. Effective Date
              </label>
              <input
                type="date"
                value={effectiveDate}
                onChange={(e) => setEffectiveDate(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Term / Duration
              </label>
              <input
                type="text"
                value={termDuration}
                onChange={(e) => setTermDuration(e.target.value)}
                placeholder="e.g. 2 years"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Governing Jurisdiction */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1">
              <Gavel className="w-3 h-3 text-amber-400" />
              Governing Jurisdiction
            </label>
            <input
              type="text"
              value={jurisdiction}
              onChange={(e) => setJurisdiction(e.target.value)}
              placeholder="e.g. State of California, United States"
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* 5. Additional Customization & Branding */}
          <div className="space-y-3 pt-2 border-t border-slate-800">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-amber-400" />
              5. Customization & Company Logo
            </label>

            <div className="flex items-center gap-3">
              <div className="flex-1">
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="Company / Firm Name"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Logo Upload Button */}
              <input
                type="file"
                ref={fileInputRef}
                accept="image/png,image/jpeg"
                onChange={handleLogoUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs text-slate-300 rounded-lg transition"
              >
                <Upload className="w-3 h-3 text-amber-400" />
                {logoBase64 ? 'Change Logo' : 'Upload Logo'}
              </button>
            </div>

            {/* Logo Preview thumbnail */}
            {logoBase64 && (
              <div className="flex items-center justify-between bg-slate-900/90 border border-slate-800 p-2 rounded-lg">
                <div className="flex items-center gap-2">
                  <img
                    src={logoBase64}
                    alt="Logo"
                    className="h-8 max-w-[120px] object-contain rounded bg-white/5 p-1"
                  />
                  <span className="text-xs text-emerald-400 font-medium">
                    Logo embedded in DOCX & PDF
                  </span>
                </div>
                <button
                  onClick={() => setLogoBase64('')}
                  className="text-slate-400 hover:text-red-400 p-1"
                  title="Remove Logo"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            <textarea
              rows={2}
              value={customizations}
              onChange={(e) => setCustomizations(e.target.value)}
              placeholder="e.g. Include company branding, professional formatting, and strict IP covenants"
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500 resize-none font-mono"
            />

            {/* Clause Toggles */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[11px] text-slate-400 font-medium">Standard Clauses:</span>
              <div className="grid grid-cols-1 gap-1.5 text-xs text-slate-300">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeConfidentiality}
                    onChange={(e) => setIncludeConfidentiality(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-amber-500 focus:ring-amber-500"
                  />
                  <span>Comprehensive Confidentiality & Non-Disclosure</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeSeverability}
                    onChange={(e) => setIncludeSeverability(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-amber-500 focus:ring-amber-500"
                  />
                  <span>Severability & Entire Agreement Provision</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeDisputeResolution}
                    onChange={(e) => setIncludeDisputeResolution(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-amber-500 focus:ring-amber-500"
                  />
                  <span>Binding Commercial Arbitration & Dispute Resolution</span>
                </label>
              </div>
            </div>
          </div>

          {/* Primary "Generate Document" CTA */}
          <div className="pt-2">
            <button
              onClick={handleGenerateDocument}
              disabled={isGenerating}
              className={`w-full py-3 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 shadow-lg transition-all ${
                isGenerating
                  ? 'bg-amber-600/50 text-amber-200 cursor-not-allowed'
                  : 'bg-gradient-to-r from-amber-500 via-amber-600 to-amber-500 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-amber-950/50'
              }`}
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                  <span>{generationStep || 'Drafting Legal Agreement...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-slate-950" />
                  <span>Generate Document</span>
                </>
              )}
            </button>
            <p className="text-[11px] text-center text-slate-500 mt-2">
              Gemini 3.8 Flash · Zero Hallucinations · Fact Integrity
            </p>
          </div>
        </aside>

        {/* RIGHT COLUMN: Document Workspace (Preview, Live Editor, Structured Covenants, Downloads) */}
        <main className="flex-1 flex flex-col p-4 lg:p-7 overflow-y-auto bg-[#0a0f1d]">
          {/* Action Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
            {/* View Mode Tabs */}
            <div className="flex items-center bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                onClick={() => setActiveTab('preview')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                  activeTab === 'preview'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                Document Preview
              </button>
              <button
                onClick={() => setActiveTab('edit')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                  activeTab === 'edit'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Edit3 className="w-3.5 h-3.5" />
                Edit Document
              </button>
              <button
                onClick={() => setActiveTab('terms')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                  activeTab === 'terms'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <ListFilter className="w-3.5 h-3.5" />
                Structured Terms ({structuredTerms.length})
              </button>
            </div>

            {/* Downloads & Utilities Group */}
            <div className="flex flex-wrap items-center gap-2">
              {/* Paper Theme Toggle */}
              <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-[11px] text-slate-400">
                <button
                  onClick={() => setPaperTheme('formal')}
                  className={`px-2 py-1 rounded ${
                    paperTheme === 'formal' ? 'bg-slate-800 text-amber-300 font-medium' : ''
                  }`}
                  title="Formal White Parchment Preview"
                >
                  Parchment
                </button>
                <button
                  onClick={() => setPaperTheme('dark')}
                  className={`px-2 py-1 rounded ${
                    paperTheme === 'dark' ? 'bg-slate-800 text-amber-300 font-medium' : ''
                  }`}
                  title="Dark Mode Preview"
                >
                  Dark
                </button>
              </div>

              {/* Sanitize Text Button */}
              <button
                onClick={handleSanitizeText}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs text-slate-300 transition"
                title="Clean smart quotes, em-dashes, and unicode artifacts"
              >
                <RefreshCw className="w-3.5 h-3.5 text-blue-400" />
                <span>Sanitize</span>
              </button>

              {/* Copy Button */}
              <button
                onClick={handleCopyDocument}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs text-slate-300 transition"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>Copy</span>
                  </>
                )}
              </button>

              {/* Download Buttons Group */}
              <div className="flex items-center bg-amber-500/10 border border-amber-500/30 rounded-xl p-0.5">
                {/* 1. TXT Export */}
                <button
                  onClick={() =>
                    downloadTxt(
                      editedDoc || generatedDoc,
                      `LegalEase_${documentType.replace(/\s+/g, '_')}`
                    )
                  }
                  className="px-2.5 py-1.5 text-xs text-amber-300 hover:text-white hover:bg-amber-500/20 rounded-lg font-medium transition"
                  title="Download plain text file"
                >
                  TXT
                </button>

                {/* 2. DOCX Export */}
                <button
                  onClick={() =>
                    downloadDocx(
                      editedDoc || generatedDoc,
                      documentType,
                      documentType.toUpperCase(),
                      logoBase64,
                      structuredTerms
                    )
                  }
                  className="flex items-center gap-1 px-3 py-1.5 text-xs bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded-lg shadow-sm transition"
                  title="Download Microsoft Word .docx format with Times New Roman and formal margins"
                >
                  <Download className="w-3.5 h-3.5" />
                  DOCX
                </button>

                {/* 3. PDF Export */}
                <button
                  onClick={() =>
                    downloadPdf(
                      editedDoc || generatedDoc,
                      documentType,
                      documentType.toUpperCase(),
                      logoBase64
                    )
                  }
                  className="flex items-center gap-1 px-3 py-1.5 text-xs text-amber-300 hover:text-white hover:bg-amber-500/20 rounded-lg font-medium transition"
                  title="Download clean legal PDF with headers, footers, and margins"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF
                </button>
              </div>
            </div>
          </div>

          {/* Sanitized Notification Toast */}
          {sanitizedNotice && (
            <div className="bg-blue-950/60 border border-blue-500/40 text-blue-200 text-xs px-4 py-2 rounded-lg mt-3 flex items-center justify-between animate-in fade-in">
              <span>
                ✓ Cleaned typographic symbols, non-breaking spaces, and smart quotes for reliable compilation.
              </span>
              <span className="text-[11px] text-blue-300 font-mono">Sanitized</span>
            </div>
          )}

          {/* Missing Facts / Information Warning Banners */}
          {missingWarnings.length > 0 && (
            <div className="bg-amber-950/30 border border-amber-500/40 rounded-xl p-3.5 mt-3 space-y-1">
              <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                Missing Information Guard (Truthfulness Protocol)
              </div>
              <p className="text-[11px] text-amber-200/80">
                LegalEase does not silently create false details. The following missing elements were clearly tagged in the document with uppercase brackets:
              </p>
              <ul className="list-disc list-inside text-xs text-amber-300 space-y-0.5 pt-1">
                {missingWarnings.map((w, i) => (
                  <li key={i}>{w}</li>
                ))}
              </ul>
            </div>
          )}

          {/* CONTENT AREA */}
          <div className="mt-4 flex-1">
            {/* TAB 1: Document Paper Preview */}
            {activeTab === 'preview' && (
              <div
                className={`w-full max-w-[850px] mx-auto rounded-lg shadow-2xl p-8 sm:p-12 transition-all min-h-[700px] border ${
                  paperTheme === 'formal'
                    ? 'bg-[#ffffff] text-slate-900 border-slate-300 font-serif-legal'
                    : 'bg-slate-900 text-slate-100 border-slate-800 font-serif-legal'
                }`}
              >
                {/* Header Logo */}
                {logoBase64 && (
                  <div className="text-center mb-6 border-b pb-4 border-slate-200">
                    <img
                      src={logoBase64}
                      alt="Company Logo"
                      className="h-14 mx-auto object-contain"
                    />
                    <div className="text-xs text-slate-500 mt-1 uppercase tracking-wider font-sans">
                      {companyName}
                    </div>
                  </div>
                )}

                {/* Formatted Text Presentation */}
                <div className="prose max-w-none text-slate-900 leading-relaxed">
                  {(editedDoc || generatedDoc).split('\n').map((line, idx) => {
                    const trimmed = line.trim();
                    if (!trimmed) {
                      return <div key={idx} className="h-4" />;
                    }

                    // Main Title
                    if (trimmed.startsWith('# ')) {
                      return (
                        <h1
                          key={idx}
                          className="text-center font-bold text-2xl uppercase tracking-wider my-6 text-slate-900 border-b-2 border-slate-800 pb-3"
                        >
                          {trimmed.slice(2)}
                        </h1>
                      );
                    }

                    // Major Heading (## )
                    if (trimmed.startsWith('## ')) {
                      return (
                        <h2
                          key={idx}
                          className="font-bold text-lg text-slate-900 mt-7 mb-2 tracking-wide uppercase border-b border-slate-200 pb-1"
                        >
                          {trimmed.slice(3)}
                        </h2>
                      );
                    }

                    // Subheading (### )
                    if (trimmed.startsWith('### ')) {
                      return (
                        <h3
                          key={idx}
                          className="font-bold text-base text-slate-800 mt-5 mb-1"
                        >
                          {trimmed.slice(4)}
                        </h3>
                      );
                    }

                    // Bullet Points
                    if (/^([-*•]|\([a-z0-9]\))\s+/.test(trimmed)) {
                      const cleanBullet = trimmed.replace(/^([-*•]|\([a-z0-9]\))\s*/, '');
                      return (
                        <div
                          key={idx}
                          className="flex items-start gap-2.5 ml-4 my-1.5 text-[15px] leading-relaxed"
                        >
                          <span className="text-slate-700 font-bold">•</span>
                          <span
                            dangerouslySetInnerHTML={{
                              __html: cleanBullet.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>'),
                            }}
                          />
                        </div>
                      );
                    }

                    // Signature Dividers
                    if (trimmed.startsWith('---') || trimmed.startsWith('___')) {
                      return (
                        <hr
                          key={idx}
                          className="border-t border-slate-300 my-6"
                        />
                      );
                    }

                    // Standard Paragraph
                    return (
                      <p
                        key={idx}
                        className="my-3 text-[15px] leading-relaxed text-justify"
                        dangerouslySetInnerHTML={{
                          __html: trimmed.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>'),
                        }}
                      />
                    );
                  })}
                </div>

                {/* Formal Footer on preview */}
                <div className="mt-12 pt-6 border-t border-slate-200 text-center text-xs text-slate-400 font-sans">
                  LegalEase Draft · Prepared for Execution · Informational & Drafting Purposes Only
                </div>
              </div>
            )}

            {/* TAB 2: Live Document Editor */}
            {activeTab === 'edit' && (
              <div className="flex flex-col h-full space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-200">
                      Live Markdown / Plaintext Legal Editor
                    </span>
                    <span className="text-[11px] bg-slate-800 px-2 py-0.5 rounded text-amber-400">
                      Changes immediately applied to DOCX & PDF exports
                    </span>
                  </div>
                  <div>
                    {editedDoc.length} chars ·{' '}
                    {editedDoc.trim().split(/\s+/).filter(Boolean).length} words
                  </div>
                </div>

                <textarea
                  value={editedDoc}
                  onChange={(e) => setEditedDoc(e.target.value)}
                  className="w-full flex-1 min-h-[640px] bg-slate-900 border border-slate-800 rounded-xl p-5 text-sm text-slate-100 font-mono leading-relaxed focus:outline-none focus:border-amber-500 shadow-inner"
                  placeholder="Legal document text..."
                />
              </div>
            )}

            {/* TAB 3: Structured Covenants Table */}
            {activeTab === 'terms' && (
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
                      <ListFilter className="w-4 h-4 text-amber-400" />
                      Extracted & Structured Covenants
                    </h3>
                    <p className="text-xs text-slate-400">
                      User terms converted from semicolons into enforceable contractual clauses
                    </p>
                  </div>
                  <span className="text-xs font-mono text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded border border-amber-500/30">
                    Schedule A Reference
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-700 bg-slate-950/60 text-slate-400 font-semibold">
                        <th className="py-3 px-4 w-16">Item</th>
                        <th className="py-3 px-4">Agreed Legal Covenant / Term</th>
                        <th className="py-3 px-4 w-32">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 font-mono">
                      {structuredTerms.map((term, i) => (
                        <tr key={i} className="hover:bg-slate-800/40 transition">
                          <td className="py-3.5 px-4 font-bold text-amber-400">
                            #{i + 1}
                          </td>
                          <td className="py-3.5 px-4 text-slate-200">
                            {term}
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                              <Check className="w-3 h-3" /> Incorporated
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {structuredTerms.length === 0 && (
                  <p className="text-xs text-slate-500 italic text-center py-6">
                    No semicolon-separated terms specified yet.
                  </p>
                )}
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Python Architecture & Streamlit Explorer Modal */}
      <PythonArchitectureViewer
        isOpen={showArchModal}
        onClose={() => setShowArchModal(false)}
      />
    </div>
  );
}
