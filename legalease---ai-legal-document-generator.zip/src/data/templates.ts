export interface LegalPreset {
  id: string;
  name: string;
  category: string;
  documentType: string;
  defaultParties: string;
  defaultTerms: string;
  defaultDuration: string;
  defaultJurisdiction: string;
  customizationNotes: string;
  recommendedClauses: string[];
}

export const LEGAL_PRESETS: LegalPreset[] = [
  {
    id: 'employment-tech',
    name: 'Software Engineer Employment Contract',
    category: 'Employment & HR',
    documentType: 'Employment Contract',
    defaultParties: 'ABC Tech Pvt. Ltd. (Employer), John Doe (Employee)',
    defaultTerms:
      'Software Engineer role; annual salary of $60,000; 2-year term; confidentiality clause; payment terms bi-weekly; 15 days written notice for termination',
    defaultDuration: '2 years',
    defaultJurisdiction: 'State of California, United States',
    customizationNotes: 'Include company branding, IP assignment, and professional formatting.',
    recommendedClauses: ['Confidentiality', 'IP Assignment', 'At-Will Status', 'Notice Period'],
  },
  {
    id: 'nda-mutual',
    name: 'Mutual Non-Disclosure Agreement (NDA)',
    category: 'Confidentiality',
    documentType: 'Non-Disclosure Agreement (NDA)',
    defaultParties: 'Apex Innovators LLC (Party A), Quantum Robotics Inc. (Party B)',
    defaultTerms:
      'Mutual evaluation of proprietary AI robotics technology; 3-year confidentiality obligation; standard carve-outs for public domain and court subpoena; return or destruction of materials upon request within 10 days',
    defaultDuration: '3 years',
    defaultJurisdiction: 'State of Delaware, United States',
    customizationNotes: 'Strict mutual covenants protecting proprietary source code and trade secrets.',
    recommendedClauses: ['Non-Circumvention', 'Defend Trade Secrets Act Notice', 'Injunctive Relief'],
  },
  {
    id: 'commercial-lease',
    name: 'Commercial Office Lease Agreement',
    category: 'Real Estate',
    documentType: 'Lease Agreement',
    defaultParties: 'Metropolitan Commercial Realty Trust (Landlord), Horizon Ventures Inc. (Tenant)',
    defaultTerms:
      'Premises located at Suite 400, 100 Financial Way; monthly base rent of $4,500 due on 1st of each month; security deposit equal to $9,000; 36-month lease duration; tenant responsible for routine interior maintenance',
    defaultDuration: '36 months',
    defaultJurisdiction: 'State of New York, United States',
    customizationNotes: 'Include standard commercial indemnity and security deposit return schedule.',
    recommendedClauses: ['Subletting Restrictions', 'Quiet Enjoyment', 'Insurance Requirements'],
  },
  {
    id: 'freelance-contractor',
    name: 'Freelance Master Services Agreement',
    category: 'Independent Contractor',
    documentType: 'Freelance Contract',
    defaultParties: 'Global Marketing Hub Inc. (Client), Elena Rostova (Contractor)',
    defaultTerms:
      'Brand design and UI/UX design deliverables; milestone payments of $3,500 upon wireframe approval and $3,500 upon final asset delivery; full transfer of copyright upon final payment; independent contractor relationship with no benefits',
    defaultDuration: '6 months',
    defaultJurisdiction: 'State of Texas, United States',
    customizationNotes: 'Clear work-for-hire copyright assignment upon payment clearance.',
    recommendedClauses: ['Work for Hire', 'Non-Solicitation', 'Expense Reimbursement'],
  },
  {
    id: 'offer-letter',
    name: 'Executive Employment Offer Letter',
    category: 'Employment & HR',
    documentType: 'Employment Offer Letter',
    defaultParties: 'Beacon Healthcare Solutions Inc. (Company), Dr. Marcus Vance (Candidate)',
    defaultTerms:
      'Vice President of Clinical Operations position; starting base salary of $175,000 annually; annual performance bonus up to 20%; 0.5% stock option grant subject to 4-year vesting; comprehensive health and 401(k) benefits; target start date of June 1, 2025',
    defaultDuration: 'At-will employment',
    defaultJurisdiction: 'State of Illinois, United States',
    customizationNotes: 'Formal corporate offer letter format on executive letterhead.',
    recommendedClauses: ['Contingent on Background Check', 'Confidentiality Agreement Execution'],
  },
  {
    id: 'general-services',
    name: 'General Professional Services Agreement',
    category: 'Corporate',
    documentType: 'Service Agreement',
    defaultParties: 'Starlight Media Group LLC (Service Provider), Vanguard Retail Partners (Customer)',
    defaultTerms:
      'Enterprise cloud management and ongoing technical support; monthly retainer of $3,200; invoices payable net-30 days; 99.9% uptime SLA commitment; either party may terminate with 30 days written notice',
    defaultDuration: '12 months with automatic renewal',
    defaultJurisdiction: 'State of Washington, United States',
    customizationNotes: 'Include standard limitation of liability capped at 12 months fees paid.',
    recommendedClauses: ['Service Level Agreement', 'Limitation of Liability', 'Force Majeure'],
  },
];
