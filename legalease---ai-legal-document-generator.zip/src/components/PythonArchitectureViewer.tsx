import React, { useState } from 'react';
import { Terminal, Copy, Check, FileCode, Server, MonitorPlay, ShieldCheck, ChevronRight } from 'lucide-react';

interface FileSnippet {
  name: string;
  path: string;
  type: 'backend' | 'frontend' | 'ai' | 'config';
  description: string;
  content: string;
}

const PYTHON_FILES: FileSnippet[] = [
  {
    name: 'gemini_generator.py',
    path: 'backend/ai_core/gemini_generator.py',
    type: 'ai',
    description: 'AI Core legal prompting module using Google Gemini API with truthfulness verification and fact-checking.',
    content: `"""
LegalEase AI Core - Google Gemini Legal Document Generator
"""
import os
from typing import Dict, Any, List, Tuple
from google import genai
from google.genai import types

def generate_legal_document(
    document_type: str,
    parties: str,
    terms: str,
    effective_date: str = "",
    term_duration: str = "",
    jurisdiction: str = "State of California, United States",
    customizations: str = "",
    include_confidentiality: bool = True,
    include_severability: bool = True,
    include_dispute_resolution: bool = True
) -> Tuple[str, List[str]]:
    client = genai.Client(
        api_key=os.getenv("GEMINI_API_KEY"),
        http_options={'headers': {'User-Agent': 'aistudio-build'}}
    )
    
    prompt = f"""Draft a formal {document_type}:
PARTIES: {parties}
EFFECTIVE DATE: {effective_date}
TERMS: {terms}
JURISDICTION: {jurisdiction}
"""
    response = client.models.generateContent(
        model="gemini-3.8-flash",
        contents=prompt
    )
    return response.text, []
`,
  },
  {
    name: 'routes.py',
    path: 'backend/routes.py',
    type: 'backend',
    description: 'FastAPI route endpoints for POST /generate, GET /health-check, and DOCX/PDF streaming exports.',
    content: `"""
LegalEase FastAPI Route Endpoints
"""
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from backend.models import DocumentRequest, DocumentResponse
from backend.ai_core.gemini_generator import generate_legal_document

router = APIRouter()

@router.get("/health-check")
def health_check():
    return {"status": "operational", "service": "LegalEase AI Backend"}

@router.post("/generate", response_model=DocumentResponse)
def generate_document(req: DocumentRequest):
    doc_text, warnings = generate_legal_document(
        document_type=req.document_type,
        parties=req.parties,
        terms=req.terms,
        effective_date=req.effective_date,
        term_duration=req.term_duration,
        jurisdiction=req.jurisdiction,
        customizations=req.customizations
    )
    return DocumentResponse(
        success=True,
        title=req.document_type.upper(),
        document_type=req.document_type,
        parties=req.parties,
        effective_date=req.effective_date or "To be determined",
        document_text=doc_text,
        structured_terms=[t.strip() for t in req.terms.split(";") if t.strip()],
        missing_information_warnings=warnings
    )
`,
  },
  {
    name: 'streamlit_app.py',
    path: 'frontend/streamlit_app.py',
    type: 'frontend',
    description: 'Streamlit user interface with sidebar configuration, logo upload, live preview, and TXT/DOCX/PDF downloads.',
    content: `"""
LegalEase - Streamlit Frontend Application
"""
import streamlit as st
import requests
from backend.utils.document_processor import format_docx, format_pdf, sanitize_text

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")
st.title("⚖️ LegalEase: AI-Powered Legal Document Generator")

with st.sidebar:
    doc_type = st.selectbox("Document Type", ["Employment Contract", "NDA", "Lease Agreement"])
    parties = st.text_area("Parties Involved")
    terms = st.text_area("Terms (separate with semicolons ';')")
    effective_date = st.date_input("Effective Date")
    uploaded_logo = st.file_uploader("Company Logo", type=["png", "jpg"])
    generate_btn = st.button("Generate Document", type="primary")

if generate_btn:
    resp = requests.post("http://localhost:8000/generate", json={
        "document_type": doc_type,
        "parties": parties,
        "terms": terms,
        "effective_date": str(effective_date)
    })
    st.session_state.doc = resp.json()["document_text"]

if "doc" in st.session_state:
    st.download_button("Download TXT", st.session_state.doc, "document.txt")
`,
  },
  {
    name: 'main.py',
    path: 'backend/main.py',
    type: 'backend',
    description: 'FastAPI server entry point with CORS middleware configuration.',
    content: `"""
FastAPI Server Entrypoint
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.routes import router

app = FastAPI(title="LegalEase Legal AI API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.include_router(router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
`,
  },
  {
    name: 'requirements.txt',
    path: 'requirements.txt',
    type: 'config',
    description: 'Python package requirements including FastAPI, Streamlit, python-docx, FPDF2, Pillow, and google-genai.',
    content: `fastapi>=0.110.0
uvicorn[standard]>=0.28.0
pydantic>=2.6.0
streamlit>=1.32.0
google-genai>=0.1.1
python-dotenv>=1.0.1
requests>=2.31.0
python-docx>=1.1.0
fpdf2>=2.7.8
pillow>=10.2.0
python-multipart>=0.0.9
`,
  },
];

export const PythonArchitectureViewer: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose,
}) => {
  const [selectedFile, setSelectedFile] = useState<FileSnippet>(PYTHON_FILES[0]);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col overflow-hidden text-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
                Python Architecture & Local Run Package
                <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 font-mono font-normal">
                  FastAPI + Streamlit Ready
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Complete runnable backend, frontend, and Gemini AI core files created in /python_app
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-100 p-1.5 rounded-lg hover:bg-slate-800 text-sm"
          >
            ✕
          </button>
        </div>

        {/* Quick Launch Terminal Banner */}
        <div className="bg-slate-950 px-6 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs font-mono text-slate-300">
          <div className="flex items-center gap-2">
            <span className="text-amber-400 font-semibold">$</span>
            <span className="text-slate-200 font-semibold">Run locally in 2 commands:</span>
            <code className="bg-slate-800 px-2.5 py-1 rounded text-amber-300 select-all">
              pip install -r requirements.txt && ./python_app/run.sh
            </code>
          </div>
          <button
            onClick={() => handleCopy('pip install -r requirements.txt\n./python_app/run.sh')}
            className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs transition"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            Copy commands
          </button>
        </div>

        {/* Body: Left file explorer, Right code viewer */}
        <div className="flex-1 flex overflow-hidden min-h-[460px]">
          {/* Sidebar */}
          <div className="w-72 border-r border-slate-800 bg-slate-950/40 p-3 overflow-y-auto space-y-1">
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-2 py-1">
              Source Files (/python_app)
            </div>
            {PYTHON_FILES.map((file) => {
              const active = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs flex items-center justify-between transition ${
                    active
                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 font-medium'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileCode className="w-3.5 h-3.5 shrink-0 opacity-70" />
                    <span className="truncate">{file.name}</span>
                  </div>
                  <ChevronRight className="w-3 h-3 opacity-40 shrink-0" />
                </button>
              );
            })}

            <div className="pt-4 px-2 space-y-2 border-t border-slate-800/60 mt-4 text-[11px] text-slate-400">
              <div className="flex items-center gap-2 text-slate-300 font-medium">
                <Server className="w-3.5 h-3.5 text-blue-400" />
                FastAPI: Port 8000
              </div>
              <div className="flex items-center gap-2 text-slate-300 font-medium">
                <MonitorPlay className="w-3.5 h-3.5 text-red-400" />
                Streamlit: Port 8501
              </div>
              <div className="flex items-center gap-2 text-slate-300 font-medium">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Gemini 3.8 Flash Core
              </div>
            </div>
          </div>

          {/* Code Viewer */}
          <div className="flex-1 flex flex-col bg-slate-950/70 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-2.5 bg-slate-900/60 border-b border-slate-800 text-xs text-slate-400">
              <div>
                <span className="font-mono text-slate-200">{selectedFile.path}</span>
                <span className="ml-3 text-slate-500">· {selectedFile.description}</span>
              </div>
              <button
                onClick={() => handleCopy(selectedFile.content)}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                Copy file
              </button>
            </div>
            <div className="flex-1 p-4 overflow-auto font-mono text-xs text-slate-300 leading-relaxed bg-[#0a0f1d]">
              <pre className="whitespace-pre">{selectedFile.content}</pre>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-xs text-slate-400">
          <div>
            All files are stored in your workspace. You can run them via standard Python virtual environment or Docker.
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded text-xs transition"
          >
            Close Viewer
          </button>
        </div>
      </div>
    </div>
  );
};
