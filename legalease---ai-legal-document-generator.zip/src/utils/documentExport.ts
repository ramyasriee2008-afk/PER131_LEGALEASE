import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  AlignmentType,
  Table,
  TableRow,
  TableCell,
  WidthType,
  ShadingType,
  BorderStyle,
  ImageRun,
  Header,
  Footer,
} from 'docx';
import { jsPDF } from 'jspdf';

// Client-side text sanitization
export function sanitizeLegalText(text: string): string {
  if (!text) return '';
  const map: Record<string, string> = {
    '\u2018': "'",
    '\u2019': "'",
    '\u201A': "'",
    '\u201B': "'",
    '\u201C': '"',
    '\u201D': '"',
    '\u201E': '"',
    '\u201F': '"',
    '\u00AB': '"',
    '\u00BB': '"',
    '\u2013': '-',
    '\u2014': '--',
    '\u2015': '--',
    '\u2212': '-',
    '\u00A0': ' ',
    '\u200B': '',
    '\u200C': '',
    '\u200D': '',
    '\uFEFF': '',
    '\u202F': ' ',
    '\u3000': ' ',
    '\u2022': '*',
    '\u2023': '*',
    '\u25AA': '*',
    '\u25CF': '*',
    '\u2026': '...',
    '\uFB01': 'fi',
    '\uFB02': 'fl',
    '\uFB00': 'ff',
    '\uFB03': 'ffi',
    '\uFB04': 'ffl',
  };

  let sanitized = text;
  for (const [k, v] of Object.entries(map)) {
    sanitized = sanitized.split(k).join(v);
  }
  sanitized = sanitized.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
  sanitized = sanitized.replace(/\n{3,}/g, '\n\n');
  return sanitized.trim();
}

// Download plain text (.txt)
export function downloadTxt(text: string, filename: string): void {
  const sanitized = sanitizeLegalText(text);
  const blob = new Blob([sanitized], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.txt') ? filename : `${filename}.txt`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// Generate & Download formal .docx document using docx library
export async function downloadDocx(
  text: string,
  docType: string,
  title: string,
  logoBase64?: string,
  structuredTerms?: string[]
): Promise<void> {
  const sanitized = sanitizeLegalText(text);
  const lines = sanitized.split('\n');

  const children: (Paragraph | Table)[] = [];

  // Optional Logo Paragraph
  if (logoBase64) {
    try {
      const pureBase64 = logoBase64.replace(/^data:image\/\w+;base64,/, '');
      const binaryString = atob(pureBase64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      children.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [
            new ImageRun({
              data: bytes,
              transformation: {
                width: 140,
                height: 50,
              },
              type: 'png',
            } as any),
          ],
        })
      );
    } catch (e) {
      console.warn('Could not render logo in DOCX:', e);
    }
  }

  // Document Title
  const docTitle = title || docType.toUpperCase();
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 100, after: 300 },
      children: [
        new TextRun({
          text: docTitle.toUpperCase(),
          bold: true,
          size: 32, // 16pt
          font: 'Times New Roman',
          color: '111827',
        }),
      ],
    })
  );

  // Parse lines into styled paragraphs
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;

    // Skip redundant title
    if (trimmed.startsWith('# ') && trimmed.slice(2).trim().toUpperCase() === docTitle.toUpperCase()) {
      continue;
    }

    // Heading 1 / 2
    if (trimmed.startsWith('# ') || trimmed.startsWith('## ')) {
      const hText = trimmed.replace(/^#+\s*/, '');
      children.push(
        new Paragraph({
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 240, after: 80 },
          children: [
            new TextRun({
              text: hText,
              bold: true,
              size: 25, // 12.5pt
              font: 'Times New Roman',
              color: '1E293B',
            }),
          ],
        })
      );
      continue;
    }

    // Sub-headings (### or SECTION)
    if (trimmed.startsWith('### ') || /^(SECTION|ARTICLE|\d+\.)\s+[A-Z\s]{3,}/.test(trimmed)) {
      const subText = trimmed.replace(/^###\s*/, '');
      children.push(
        new Paragraph({
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 180, after: 60 },
          children: [
            new TextRun({
              text: subText,
              bold: true,
              size: 23, // 11.5pt
              font: 'Times New Roman',
              color: '334155',
            }),
          ],
        })
      );
      continue;
    }

    // Bullet items
    if (/^([-*•]|\([a-z0-9]\))\s+/.test(trimmed)) {
      const bulletBody = trimmed.replace(/^([-*•]|\([a-z0-9]\))\s*/, '');
      const runs = parseMarkdownBold(bulletBody);
      children.push(
        new Paragraph({
          bullet: { level: 0 },
          spacing: { after: 60, line: 276 },
          children: runs,
        })
      );
      continue;
    }

    // Signature Divider
    if (trimmed.startsWith('---') || trimmed.startsWith('___')) {
      children.push(
        new Paragraph({
          spacing: { before: 200, after: 200 },
          children: [
            new TextRun({
              text: '_________________________________________________________________',
              color: 'CBD5E1',
              font: 'Times New Roman',
            }),
          ],
        })
      );
      continue;
    }

    // Standard Paragraph
    const runs = parseMarkdownBold(trimmed);
    children.push(
      new Paragraph({
        alignment: AlignmentType.JUSTIFIED,
        spacing: { after: 120, line: 276 }, // 1.15 line spacing
        children: runs,
      })
    );
  }

  // Structured Terms Table if available
  if (structuredTerms && structuredTerms.length > 0) {
    children.push(
      new Paragraph({
        spacing: { before: 300, after: 100 },
        children: [
          new TextRun({
            text: 'SCHEDULE A -- SUMMARY OF KEY TERMS & CONDITIONS',
            bold: true,
            size: 22,
            font: 'Times New Roman',
          }),
        ],
      })
    );

    const rows: TableRow[] = [];
    // Header Row
    rows.push(
      new TableRow({
        children: [
          new TableCell({
            width: { size: 15, type: WidthType.PERCENTAGE },
            shading: { type: ShadingType.CLEAR, fill: 'E2E8F0' },
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: 'Covenant #',
                    bold: true,
                    size: 20,
                    font: 'Times New Roman',
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            width: { size: 85, type: WidthType.PERCENTAGE },
            shading: { type: ShadingType.CLEAR, fill: 'E2E8F0' },
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: 'Agreed Specification / Covenant',
                    bold: true,
                    size: 20,
                    font: 'Times New Roman',
                  }),
                ],
              }),
            ],
          }),
        ],
      })
    );

    // Data Rows
    structuredTerms.forEach((term, index) => {
      rows.push(
        new TableRow({
          children: [
            new TableCell({
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: `Term ${index + 1}`,
                      size: 19,
                      font: 'Times New Roman',
                      bold: true,
                    }),
                  ],
                }),
              ],
            }),
            new TableCell({
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: term,
                      size: 19,
                      font: 'Times New Roman',
                    }),
                  ],
                }),
              ],
            }),
          ],
        })
      );
    });

    children.push(
      new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows,
      })
    );
  }

  // Create document with 1-inch margins and headers/footers
  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: 1440, // 1 inch = 1440 dxa
              bottom: 1440,
              left: 1440,
              right: 1440,
            },
          },
        },
        headers: {
          default: new Header({
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                children: [
                  new TextRun({
                    text: `LEGAL AGREEMENT | ${docType.toUpperCase()}`,
                    size: 16,
                    color: '94A3B8',
                    font: 'Times New Roman',
                  }),
                ],
              }),
            ],
          }),
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: 'LegalEase Draft -- For Drafting & Informational Purposes Only',
                    size: 16,
                    italics: true,
                    color: '94A3B8',
                    font: 'Times New Roman',
                  }),
                ],
              }),
            ],
          }),
        },
        children,
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  const safeName = docType.replace(/[^a-zA-Z0-9]/g, '_');
  link.download = `LegalEase_${safeName}.docx`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// Generate & Download crisp PDF using jsPDF
export function downloadPdf(
  text: string,
  docType: string,
  title: string,
  logoBase64?: string
): void {
  const sanitized = sanitizeLegalText(text);
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  const contentWidth = pageWidth - margin * 2;

  let y = margin;

  // Add header & footer helper
  const addHeaderFooter = (pageNumber: number) => {
    // Header
    doc.setFont('times', 'italic');
    doc.setFontSize(8);
    doc.setTextColor(140, 140, 140);
    doc.text(`LEGAL DOCUMENT | ${docType.toUpperCase()}`, pageWidth - margin, 12, { align: 'right' });
    doc.setDrawColor(220, 220, 220);
    doc.line(margin, 15, pageWidth - margin, 15);

    // Footer
    doc.line(margin, pageHeight - 14, pageWidth - margin, pageHeight - 14);
    doc.text('LegalEase Draft - Informational & Drafting Purposes Only', margin, pageHeight - 9);
    doc.text(`Page ${pageNumber}`, pageWidth - margin, pageHeight - 9, { align: 'right' });
  };

  let currentPage = 1;
  addHeaderFooter(currentPage);

  // Logo
  if (logoBase64) {
    try {
      doc.addImage(logoBase64, 'PNG', (pageWidth - 35) / 2, y, 35, 14);
      y += 18;
    } catch (e) {
      console.warn('Could not draw logo in PDF:', e);
    }
  }

  // Document Title
  const docTitle = (title || docType).toUpperCase();
  doc.setFont('times', 'bold');
  doc.setFontSize(15);
  doc.setTextColor(20, 30, 45);
  doc.text(docTitle, pageWidth / 2, y, { align: 'center' });
  y += 10;

  const lines = sanitized.split('\n');

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) {
      y += 3;
      continue;
    }

    // Page overflow check
    if (y > pageHeight - 25) {
      doc.addPage();
      currentPage++;
      addHeaderFooter(currentPage);
      y = margin + 5;
    }

    // Skip redundant title
    if (trimmed.startsWith('# ') && trimmed.slice(2).trim().toUpperCase() === docTitle) {
      continue;
    }

    // Major Section Heading
    if (trimmed.startsWith('# ') || trimmed.startsWith('## ')) {
      const hText = trimmed.replace(/^#+\s*/, '');
      y += 4;
      if (y > pageHeight - 25) {
        doc.addPage();
        currentPage++;
        addHeaderFooter(currentPage);
        y = margin + 5;
      }
      doc.setFont('times', 'bold');
      doc.setFontSize(11.5);
      doc.setTextColor(25, 35, 50);
      doc.text(hText, margin, y);
      y += 6;
      continue;
    }

    // Subsection
    if (trimmed.startsWith('### ') || /^(SECTION|ARTICLE|\d+\.)\s+[A-Z\s]{3,}/.test(trimmed)) {
      const subText = trimmed.replace(/^###\s*/, '');
      y += 3;
      if (y > pageHeight - 25) {
        doc.addPage();
        currentPage++;
        addHeaderFooter(currentPage);
        y = margin + 5;
      }
      doc.setFont('times', 'bold');
      doc.setFontSize(10.5);
      doc.setTextColor(35, 45, 60);
      doc.text(subText, margin, y);
      y += 5.5;
      continue;
    }

    // Bullet points
    if (/^([-*•]|\([a-z0-9]\))\s+/.test(trimmed)) {
      const bulletBody = trimmed.replace(/^([-*•]|\([a-z0-9]\))\s*/, '').replace(/\*\*(.*?)\*\*/g, '$1');
      doc.setFont('times', 'normal');
      doc.setFontSize(9.5);
      doc.setTextColor(30, 30, 30);
      doc.text('•', margin + 2, y);
      const splitText = doc.splitTextToSize(bulletBody, contentWidth - 8);
      doc.text(splitText, margin + 6, y);
      y += splitText.length * 4.5 + 2;
      continue;
    }

    // Signature Divider
    if (trimmed.startsWith('---') || trimmed.startsWith('___')) {
      y += 3;
      doc.setDrawColor(200, 200, 200);
      doc.line(margin, y, margin + 80, y);
      y += 5;
      continue;
    }

    // Normal Paragraph
    const cleanPara = trimmed.replace(/\*\*(.*?)\*\*/g, '$1');
    doc.setFont('times', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(25, 25, 25);
    const splitParagraph = doc.splitTextToSize(cleanPara, contentWidth);
    doc.text(splitParagraph, margin, y, { align: 'justify', maxWidth: contentWidth });
    y += splitParagraph.length * 4.6 + 2.5;
  }

  const safeName = docType.replace(/[^a-zA-Z0-9]/g, '_');
  doc.save(`LegalEase_${safeName}.pdf`);
}

// Parse markdown bold into docx TextRun array
function parseMarkdownBold(text: string): TextRun[] {
  const parts = text.split(/(\*\*.*?\*\*)/g);
  const runs: TextRun[] = [];

  for (const part of parts) {
    if (!part) continue;
    if (part.startsWith('**') && part.endsWith('**')) {
      runs.push(
        new TextRun({
          text: part.slice(2, -2),
          bold: true,
          font: 'Times New Roman',
          size: 21, // ~10.5pt
          color: '1E293B',
        })
      );
    } else {
      runs.push(
        new TextRun({
          text: part,
          font: 'Times New Roman',
          size: 21,
          color: '1E293B',
        })
      );
    }
  }
  return runs;
}
