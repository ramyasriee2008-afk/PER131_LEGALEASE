import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

app.use(express.json({ limit: '15mb' }));

// Initialize Google GenAI client server-side
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Supported Legal Document Types
const SUPPORTED_DOCUMENT_TYPES = [
  'Employment Contract',
  'Non-Disclosure Agreement (NDA)',
  'Lease Agreement',
  'Service Agreement',
  'Freelance Contract',
  'Employment Offer Letter',
  'General Contract',
  'General Agreement',
  'Partnership Agreement',
  'Consulting Agreement',
];

// Helper: Sanitize text for problematic characters and typographic symbols
function sanitizeText(text: string): string {
  if (!text) return '';
  const map: Record<string, string> = {
    '\u2018': "'",
    '\u2019': "'",
    '\u201A': "'",
    '\u201B': "'",
    '\u201C': '"',
    '\u201D': '"',
    '\u201E': '"',
    '\u201F': '"',
    '\u00AB': '"',
    '\u00BB': '"',
    '\u2013': '-',
    '\u2014': '--',
    '\u2015': '--',
    '\u2212': '-',
    '\u00A0': ' ',
    '\u200B': '',
    '\u200C': '',
    '\u200D': '',
    '\uFEFF': '',
    '\u202F': ' ',
    '\u3000': ' ',
    '\u2022': '*',
    '\u2023': '*',
    '\u25AA': '*',
    '\u25CF': '*',
    '\u2026': '...',
    '\uFB01': 'fi',
    '\uFB02': 'fl',
    '\uFB00': 'ff',
    '\uFB03': 'ffi',
    '\uFB04': 'ffl',
  };

  let sanitized = text;
  for (const [k, v] of Object.entries(map)) {
    sanitized = sanitized.split(k).join(v);
  }
  // Remove control characters except newlines/tabs
  sanitized = sanitized.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
  sanitized = sanitized.replace(/\n{3,}/g, '\n\n');
  return sanitized.trim();
}

// Helper: Parse semicolon-separated terms into structured array
function parseSemicolonTerms(terms: string): string[] {
  if (!terms) return [];
  if (terms.includes(';')) {
    return terms
      .split(';')
      .map((t) => t.trim().replace(/^[-*•\d.)\s]+/, ''))
      .filter((t) => t.length > 2);
  }
  return terms
    .split(/\n+|(?<=[.!?])\s+(?=[A-Z0-9])/)
    .map((t) => t.trim().replace(/^[-*•\d.)\s]+/, ''))
    .filter((t) => t.length > 2);
}

// Missing information detection
function checkMissingInformation(
  docType: string,
  parties: string,
  terms: string,
  effectiveDate: string
): string[] {
  const warnings: string[] = [];
  const dt = docType.toLowerCase();
  const t = terms.toLowerCase();

  if (!parties || parties.trim().length < 5) {
    warnings.push('Both legal parties (Employer/Employee, Discloser/Recipient, etc.) should be clearly specified.');
  }
  if (!effectiveDate || !effectiveDate.trim()) {
    warnings.push('Effective date was omitted. The generated contract marks this as [EFFECTIVE DATE].');
  }

  if (dt.includes('employment') || dt.includes('offer')) {
    if (!t.includes('salary') && !t.includes('compensation') && !t.includes('pay') && !t.includes('$')) {
      warnings.push('Compensation or salary was omitted; marked explicitly as [COMPENSATION TO BE SPECIFIED].');
    }
    if (!t.includes('role') && !t.includes('title') && !t.includes('position')) {
      warnings.push('Job title or position was omitted; marked explicitly as [JOB TITLE / DUTIES].');
    }
  } else if (dt.includes('lease')) {
    if (!t.includes('rent') && !t.includes('$')) {
      warnings.push('Monthly rent or security deposit was omitted; marked as [MONTHLY RENT AMOUNT].');
    }
    if (!t.includes('address') && !t.includes('premises') && !t.includes('property')) {
      warnings.push('Property address was omitted; marked as [PREMISES ADDRESS].');
    }
  } else if (dt.includes('nda') || dt.includes('non-disclosure')) {
    if (!t.includes('year') && !t.includes('term') && !t.includes('duration')) {
      warnings.push('Confidentiality duration was omitted; marked as [CONFIDENTIALITY DURATION (e.g., 3 years)].');
    }
  }

  return warnings;
}

// Fallback legal template if offline or Gemini API key unconfigured
function generateFallbackDocument(
  docType: string,
  parties: string,
  terms: string,
  effectiveDate: string,
  termDuration: string,
  jurisdiction: string,
  includeConfidentiality: boolean,
  includeSeverability: boolean,
  includeDisputeResolution: boolean
): string {
  const dateStr = effectiveDate || '[EFFECTIVE DATE TO BE INSERTED]';
  const durationStr = termDuration || 'two (2) years from the Effective Date';
  const covenants = parseSemicolonTerms(terms);

  let formattedTerms = '';
  if (covenants.length > 0) {
    formattedTerms = covenants
      .map((c, i) => `**Section 3.${i + 1}. Specific Covenant:** ${c}\n`)
      .join('\n');
  } else {
    formattedTerms = `**Section 3.1. Agreed Terms:** ${terms || 'Terms as mutually agreed between the Parties in writing.'}\n`;
  }

  return `# ${docType.toUpperCase()}

This **${docType}** (the "Agreement") is made and entered into as of **${dateStr}** (the "Effective Date"), by and between:

**PARTIES TO THIS AGREEMENT:**
${parties}

(Collectively referred to as the "Parties" and individually as a "Party").

---

### RECITALS

**WHEREAS**, the Parties wish to establish a formal contractual relationship pursuant to the covenants and provisions set forth herein; and

**WHEREAS**, each Party possesses the legal authority, corporate power, and capacity to execute and perform this Agreement;

**NOW, THEREFORE**, in consideration of the mutual covenants, representations, and valuable consideration contained herein, the Parties agree as follows:

---

## SECTION 1. SCOPE AND PERFORMANCE
1.1 **Engagement.** The Parties agree to perform their respective covenants, duties, and responsibilities as contemplated under this ${docType}.
1.2 **Standard of Conduct.** Each Party shall perform its obligations in good faith, in accordance with applicable industry standards, and in strict compliance with all relevant laws and regulations.

## SECTION 2. TERM AND TERMINATION
2.1 **Term.** This Agreement shall commence upon the Effective Date and remain in full force and effect for **${durationStr}**, unless terminated earlier in accordance with this Section.
2.2 **Termination for Cause.** Either Party may terminate this Agreement immediately upon written notice if the other Party materially breaches any term herein and fails to cure such breach within fifteen (15) calendar days of receiving written notice thereof.

## SECTION 3. SPECIFIC TERMS AND CONDITIONS
The Parties agree to the following specific covenants and contractual conditions:

${formattedTerms}
${
  includeConfidentiality
    ? `## SECTION 4. CONFIDENTIALITY & PROPRIETARY INFORMATION
4.1 **Confidentiality.** Each Party shall protect and preserve the confidentiality of all proprietary technical, financial, or business information disclosed under this Agreement with no less than reasonable care.
4.2 **Non-Disclosure.** Neither Party shall disclose such Confidential Information to third parties without prior written consent.`
    : ''
}

## SECTION 5. GOVERNING LAW & JURISDICTION
5.1 **Governing Law.** This Agreement shall be construed, interpreted, and governed under the laws of **${
    jurisdiction || 'State of California, United States'
  }**, without regard to conflict of laws principles.
${
  includeDisputeResolution
    ? `5.2 **Dispute Resolution.** Any claim or dispute arising under this Agreement shall first be negotiated in good faith. If unresolved within thirty (30) days, the matter shall be settled through binding commercial arbitration.`
    : ''
}

${
  includeSeverability
    ? `## SECTION 6. SEVERABILITY & ENTIRE AGREEMENT
6.1 **Severability.** If any provision of this Agreement is deemed unenforceable or invalid, the remaining provisions shall remain in full legal force and effect.
6.2 **Entire Agreement.** This Agreement constitutes the complete and exclusive statement of understanding between the Parties, superseding all prior oral or written negotiations.`
    : ''
}

---

### EXECUTION AND SIGNATURES

**IN WITNESS WHEREOF**, the Parties hereto have executed this ${docType} by their authorized representatives as of the Effective Date.


_____________________________________________
**FOR PARTY 1 / EMPLOYER / DISCLOSER**
Authorized Signature: _______________________
Printed Name: _______________________________
Title: ______________________________________
Date: _______________________________________


_____________________________________________
**FOR PARTY 2 / EMPLOYEE / RECIPIENT**
Authorized Signature: _______________________
Printed Name: _______________________________
Title: ______________________________________
Date: _______________________________________
`;
}

// API Routes
app.get('/api/health-check', (_req, res) => {
  res.json({
    status: 'operational',
    service: 'LegalEase AI Legal Document Generator',
    version: '1.0.0',
    gemini_configured: Boolean(process.env.GEMINI_API_KEY),
    supported_document_types: SUPPORTED_DOCUMENT_TYPES,
  });
});

app.post('/api/sanitize', (req, res) => {
  const { text } = req.body;
  if (!text) {
    return res.status(400).json({ error: 'Text is required for sanitization' });
  }
  const sanitized = sanitizeText(text);
  res.json({
    sanitized_text: sanitized,
    characters_processed: text.length,
  });
});

app.post('/api/generate', async (req, res) => {
  try {
    const {
      document_type,
      parties,
      terms,
      effective_date,
      term_duration,
      jurisdiction,
      customizations,
      include_confidentiality = true,
      include_severability = true,
      include_dispute_resolution = true,
    } = req.body;

    if (!document_type || !parties) {
      return res.status(400).json({
        error: 'Both "document_type" and "parties" are required parameters.',
      });
    }

    const structuredTerms = parseSemicolonTerms(terms || '');
    const warnings = checkMissingInformation(
      document_type,
      parties,
      terms || '',
      effective_date || ''
    );

    let documentText = '';

    // Check if Gemini API key is configured
    if (process.env.GEMINI_API_KEY) {
      try {
        const systemInstruction = `You are LegalEase Senior Legal Counsel AI, an expert contract drafting attorney.
Draft a comprehensive, professional, structured, and legally binding ${document_type}.

STRICT DRAFTING RULES:
1. TRUTHFULNESS & FACT INTEGRITY:
   - Do NOT invent or fabricate facts, salaries, roles, or dates that the user did not supply.
   - If essential information was omitted (such as specific salary figures, premises addresses, or term duration), clearly mark it with uppercase bracketed placeholders, e.g. [INSERT SPECIFIC SALARY AMOUNT] or [INSERT PROPERTY ADDRESS].
2. STRUCTURE:
   - Title: Centered bold title (e.g. # ${document_type.toUpperCase()}).
   - Recitals / Preamble: Identify the Parties and Effective Date clearly.
   - Operative Covenants: Numbered Sections (SECTION 1. SCOPE, SECTION 2. TERM & TERMINATION, SECTION 3. SPECIFIC COVENANTS, etc.).
   - Standard Boilerplate: Confidentiality, Governing Law, Severability, Entire Agreement, Dispute Resolution.
   - Signatures: Formal execution block ("IN WITNESS WHEREOF...") with signature lines, names, titles, and dates.
3. COVENANTS:
   - Convert all user-supplied terms (especially semicolon-separated terms) into formal legal covenants.
4. FORMATTING:
   - Use clean Markdown (# Title, ## Section, ### Subsections, **Bold** for defined terms). Do NOT include conversational filler, preamble chat, or post-document explanations. Output ONLY the legal document.`;

        const userPrompt = `Draft a formal ${document_type} with the following details:
DOCUMENT TYPE: ${document_type}
PARTIES: ${parties}
EFFECTIVE DATE: ${effective_date || '[EFFECTIVE DATE TO BE INSERTED]'}
TERM / DURATION: ${term_duration || '[AS MUTUALLY AGREED]'}
GOVERNING JURISDICTION: ${jurisdiction || 'State of California, United States'}

USER COVENANTS & TERMS:
${terms || 'Standard covenants for this agreement type.'}

CUSTOMIZATION / BRANDING INSTRUCTIONS:
${customizations || 'Formal corporate presentation and structured legal formatting.'}

OPTIONAL PROVISIONS REQUESTED:
- Confidentiality: ${include_confidentiality ? 'Include comprehensive clause' : 'Omit'}
- Severability: ${include_severability ? 'Include standard clause' : 'Omit'}
- Dispute Resolution: ${include_dispute_resolution ? 'Include binding arbitration clause' : 'Omit'}

Draft the complete legal agreement now.`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: userPrompt,
          config: {
            systemInstruction: systemInstruction,
            temperature: 0.2,
          },
        });

        if (response && response.text) {
          documentText = response.text.trim();
        }
      } catch (geminiError: any) {
        console.error('Gemini API call failed, falling back to structured template:', geminiError?.message);
        warnings.push(`Gemini note: ${geminiError?.message || 'Using high-fidelity legal template.'}`);
      }
    }

    // Fallback if Gemini call failed or key not present
    if (!documentText) {
      documentText = generateFallbackDocument(
        document_type,
        parties,
        terms || '',
        effective_date || '',
        term_duration || '',
        jurisdiction || 'State of California, United States',
        include_confidentiality,
        include_severability,
        include_dispute_resolution
      );
    }

    res.json({
      success: true,
      title: document_type.toUpperCase(),
      document_type,
      parties,
      effective_date: effective_date || 'To be determined',
      document_text: documentText,
      structured_terms: structuredTerms,
      missing_information_warnings: warnings,
    });
  } catch (error: any) {
    console.error('Generate error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate document' });
  }
});

// Setup Vite middlewares for React frontend
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`LegalEase Server running on http://0.0.0.0:${port}`);
  });
}

startServer();
